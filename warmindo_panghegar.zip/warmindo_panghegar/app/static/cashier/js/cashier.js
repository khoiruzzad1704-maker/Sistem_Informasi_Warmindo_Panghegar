const CASHIER_CART_KEY = "warmindo_cashier_cart_v1";
let selectedPaymentMethod = null;
let selectedTableId = null;
let selectedFloor = 1;

function selectFloor(floor){
  selectedFloor = floor;
  selectedTableId = null;
  const b1 = document.getElementById('floorBtn1');
  const b2 = document.getElementById('floorBtn2');
  if(b1) b1.className = floor === 1 ? 'btn btn-primary' : 'btn btn-ghost';
  if(b2) b2.className = floor === 2 ? 'btn btn-primary' : 'btn btn-ghost';
  renderTables();
}

function renderTables(){
  const grid = document.getElementById('tableGrid');
  if(!grid) return;
    grid.innerHTML = '';
    const maxTables = selectedFloor === 1 ? 20 : 30;
    for(let i=1;i<=maxTables;i++){
      const btn = document.createElement('button');
      btn.className = 'table-btn compact';
      btn.textContent = i;
      btn.onclick = () => selectTable(i);
      if(selectedTableId === i) btn.classList.add('selected');
      grid.appendChild(btn);
  }
}

function selectTable(tableNum){
  selectedTableId = tableNum;
  renderTables();
  const sel = document.getElementById('selectedTable');
  if(sel) sel.textContent = `${tableNum} (Lantai ${selectedFloor})`;
}

function rupiah(n){
  return "Rp " + Math.round(n).toLocaleString("id-ID");
}

function loadCart(){
  const raw = localStorage.getItem(CASHIER_CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveCart(cart){
  localStorage.setItem(CASHIER_CART_KEY, JSON.stringify(cart));
  renderCart();
}

function addToCart(menuId, name, price, category){
  const cart = loadCart();
  const idx = cart.findIndex(x => x.menu_id === menuId);
  if(idx >= 0) cart[idx].qty += 1;
  else cart.push({menu_id:menuId, name, price, category, qty:1});
  saveCart(cart);
}

function inc(menuId){
  const cart = loadCart();
  const it = cart.find(x => x.menu_id === menuId);
  if(it) it.qty += 1;
  saveCart(cart);
}

function dec(menuId){
  const cart = loadCart();
  const it = cart.find(x => x.menu_id === menuId);
  if(!it) return;
  it.qty -= 1;
  const next = cart.filter(x => x.qty > 0);
  saveCart(next);
}

function clearCart(){
  localStorage.removeItem(CASHIER_CART_KEY);
  renderCart();
}

function renderCart(){
  const cart = loadCart();
  const count = cart.reduce((a,x)=>a+x.qty,0);
  const total = cart.reduce((a,x)=>a+(x.qty*x.price),0);

  const countEl = document.getElementById("cartCount");
  const totalEl = document.getElementById("cartTotal");
  const listEl = document.getElementById("cartItems");

  if(countEl) countEl.textContent = `${count} item`;
  if(totalEl) totalEl.textContent = rupiah(total);

  if(!listEl) return;
  listEl.innerHTML = "";

  if(cart.length === 0){
    listEl.innerHTML = `<div class="mi-sub">Keranjang kosong. Tambahkan menu terlebih dahulu.</div>`;
    return;
  }

  cart.forEach(it=>{
    const row = document.createElement("div");
    row.className = "cartRow";
    row.innerHTML = `
      <div>
        <div class="name">${it.name}</div>
        <div class="muted">${it.category} • ${rupiah(it.price)}</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <button class="qtyBtn" onclick="dec(${it.menu_id})">−</button>
        <b>${it.qty}</b>
        <button class="qtyBtn" onclick="inc(${it.menu_id})">+</button>
      </div>
    `;
    listEl.appendChild(row);
  });
}

function filterMenu(){
  const q = (document.getElementById("search")?.value || "").toLowerCase();
  const cat = document.getElementById("cat")?.value || "ALL";
  const items = document.querySelectorAll(".menuItem");
  items.forEach(el=>{
    const name = el.getAttribute("data-name") || "";
    const c = el.getAttribute("data-cat") || "";
    const okName = name.includes(q);
    const okCat = (cat === "ALL") || (c === cat);
    el.style.display = okName && okCat ? "flex" : "none";
  });
}

function openCheckoutModal(){
  const cart = loadCart();
  if(cart.length === 0){
    alert("Keranjang kosong.");
    return;
  }
  selectedPaymentMethod = null;
  selectedTableId = null;
  selectedFloor = 1;
  document.getElementById("checkoutModal").classList.add("active");
  // initialize floor buttons and tables
  try{ selectFloor(1); }catch(e){}
  const sel = document.getElementById('selectedTable'); if(sel) sel.textContent = '-';
  updateSummary();
}

function closeCheckoutModal(){
  document.getElementById("checkoutModal").classList.remove("active");
  // Reset modal display sections
  document.getElementById("nameSection").style.display = "block";
  document.getElementById("paymentMethodSection").style.display = "block";
  document.getElementById("summarySection").style.display = "block";
  document.getElementById("qrisSection").style.display = "none";
  document.getElementById("continueActions").style.display = "flex";
  document.getElementById("afterQrisActions").style.display = "none";
  document.getElementById("tunaiActionsBtn").style.display = "none";
  // Reset form
  document.getElementById("customerName").value = "";
  selectedPaymentMethod = null;
  selectedTableId = null;
  selectedFloor = 1;
  resetPaymentButtons();
}

function selectPaymentMethod(method){
  selectedPaymentMethod = method;
  document.getElementById("selectedPaymentMethod").textContent = 
    method === "tunai" ? "Tunai (💵)" : "Non-Tunai - QRIS (💳)";
  
  // Update button styles
  resetPaymentButtons();
  if(method === "tunai"){
    const t = document.getElementById("tunaiBtn");
    if(t) t.className = 'btn btn-primary payment-method-btn';
  } else {
    const n = document.getElementById("nontunaiBtn");
    if(n) n.className = 'btn btn-primary payment-method-btn';
  }
}

function resetPaymentButtons(){
  const t = document.getElementById("tunaiBtn");
  const n = document.getElementById("nontunaiBtn");
  if(t) t.className = 'btn btn-ghost payment-method-btn';
  if(n) n.className = 'btn btn-ghost payment-method-btn';
}

function updateSummary(){
  const cart = loadCart();
  const total = cart.reduce((a,x)=>a+(x.qty*x.price),0);
  const html = cart.map(it => `
    <div class="summary-row">
      <span>${it.name} × ${it.qty}</span>
      <span>${rupiah(it.qty * it.price)}</span>
    </div>
  `).join("") + `
    <div class="summary-row">
      <span>TOTAL</span>
      <span>${rupiah(total)}</span>
    </div>
  `;
  document.getElementById("checkoutSummary").innerHTML = html;
}

function requestPayment(){
  const customerName = document.getElementById("customerName").value.trim();
  if(!customerName){
    alert("Masukkan nama pelanggan terlebih dahulu");
    return;
  }
  if(!selectedPaymentMethod){
    alert("Pilih metode pembayaran terlebih dahulu");
    return;
  }
  // Non-tunai: show QRIS popup (hide seating)
  if(selectedPaymentMethod === "nontunai"){
    document.getElementById("nameSection").style.display = "none";
    document.getElementById("paymentMethodSection").style.display = "none";
    document.getElementById("summarySection").style.display = "none";
    // hide seating area when showing QRIS
    const tableSec = document.getElementById("tableSection"); if(tableSec) tableSec.style.display = "none";
    document.getElementById("qrisSection").style.display = "block";
    document.getElementById("continueActions").style.display = "none";
    document.getElementById("afterQrisActions").style.display = "block";
    document.getElementById("tunaiActionsBtn").style.display = "none";
    // Show QRIS image
    document.getElementById("qrisImage").src = "/static/images/QRIS Mockup.png";
    return;
  }

  // Tunai: skip floor selection and submit immediately
  if(selectedPaymentMethod === "tunai"){
    // hide modal to avoid flicker
    document.getElementById("checkoutModal").classList.remove("active");
    // submit order as tunai (table may be null)
    const cname = customerName;
    processPaymentCashier(cname, "tunai");
    return;
  }
}

function processCashPayment(){
  const btn = document.getElementById("tunaiFinishBtn");
  if(btn) btn.disabled = true;
  const customerName = document.getElementById("customerName").value.trim();
  processPaymentCashier(customerName, "tunai");
}

function processPaymentFinalize(){
  const btn = document.getElementById("paymentDoneBtn");
  if(btn) btn.disabled = true;
  const customerName = document.getElementById("customerName").value.trim();
  processPaymentCashier(customerName, "nontunai");
}

async function processPaymentCashier(customerName, paymentMethod){
  const cart = loadCart();
  const payload = {
    source: "KASIR",
    customer_name: customerName,
    table_id: selectedTableId ? selectedTableId : null,
    items: cart.map(x => ({menu_id:x.menu_id, qty:x.qty})),
    payment_status: "PAID",
    payment_method: paymentMethod
  };
  
  const res = await fetch("/api/order", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  
  if(!data.ok){
    alert("Gagal membuat pesanan: " + (data.error || "unknown"));
    return;
  }
  
  clearCart();
  window.location.href = "/staff/cashier/receipt/" + data.order_id;
}

document.addEventListener("DOMContentLoaded", ()=>{
  renderCart();
});
