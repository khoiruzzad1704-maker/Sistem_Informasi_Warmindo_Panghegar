const CART_KEY = "warmindo_cart_v2";
let selectedTableId = null;
let selectedFloor = 1;

function rupiah(n){
  return "Rp " + Math.round(n).toLocaleString("id-ID");
}

function loadCart(){
  const raw = localStorage.getItem(CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  renderCart();
}

function addToCart(menuId, name, price, category){
  const cart = loadCart();
  const idx = cart.findIndex(x => x.menu_id === menuId);
  if(idx >= 0) cart[idx].qty += 1;
  else cart.push({menu_id:menuId, name, price, category, qty:1});
  saveCart(cart);
}

function inc(menuId){
  const cart = loadCart();
  const it = cart.find(x => x.menu_id === menuId);
  if(it) it.qty += 1;
  saveCart(cart);
}

function dec(menuId){
  const cart = loadCart();
  const it = cart.find(x => x.menu_id === menuId);
  if(!it) return;
  it.qty -= 1;
  const next = cart.filter(x => x.qty > 0);
  saveCart(next);
}

function clearCart(){
  localStorage.removeItem(CART_KEY);
  renderCart();
}

function renderCart(){
  const cart = loadCart();
  const count = cart.reduce((a,x)=>a+x.qty,0);
  const total = cart.reduce((a,x)=>a+(x.qty*x.price),0);

  const countEl = document.getElementById("cartCount");
  const navCount = document.getElementById("navCartCount");
  const totalEl = document.getElementById("cartTotal");
  const listEl = document.getElementById("cartItems");

  if(navCount) navCount.textContent = count;
  if(countEl) countEl.textContent = `${count} item`;
  if(totalEl) totalEl.textContent = rupiah(total);

  if(!listEl) return;
  listEl.innerHTML = "";

  if(cart.length === 0){
    listEl.innerHTML = `<div class="mi-sub">Keranjang kosong. Tambahkan menu terlebih dahulu.</div>`;
    return;
  }

  cart.forEach(it=>{
    const row = document.createElement("div");
    row.className = "cartRow";
    row.innerHTML = `
      <div>
        <div class="name">${it.name}</div>
        <div class="muted">${it.category} • ${rupiah(it.price)}</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <button class="qtyBtn" onclick="dec(${it.menu_id})">−</button>
        <b>${it.qty}</b>
        <button class="qtyBtn" onclick="inc(${it.menu_id})">+</button>
      </div>
    `;
    listEl.appendChild(row);
  });
}

function filterMenu(){
  const q = (document.getElementById("search")?.value || "").toLowerCase();
  const cat = document.getElementById("cat")?.value || "ALL";
  const items = document.querySelectorAll(".menuItem");
  items.forEach(el=>{
    const name = el.getAttribute("data-name") || "";
    const c = el.getAttribute("data-cat") || "";
    const okName = name.includes(q);
    const okCat = (cat === "ALL") || (c === cat);
    el.style.display = okName && okCat ? "flex" : "none";
  });
}

function openCheckoutModal(tableId){
  const cart = loadCart();
  if(cart.length === 0){
    alert("Keranjang kosong.");
    return;
  }
  selectedTableId = null;
  selectedFloor = 1;
  document.getElementById("checkoutModal").classList.add("active");
  selectFloor(1);
  updateSummary();
}

function closeCheckoutModal(){
  document.getElementById("checkoutModal").classList.remove("active");
  // Reset modal display sections
  document.getElementById("nameSection").style.display = "block";
  document.getElementById("tableSection").style.display = "block";
  document.getElementById("summarySection").style.display = "block";
  document.getElementById("qrisSection").style.display = "none";
  document.getElementById("continueActions").style.display = "flex";
  document.getElementById("afterQrisActions").style.display = "none";
  // Reset form
  document.getElementById("customerName").value = "";
  selectedTableId = null;
  selectedFloor = 1;
}

function selectFloor(floor){
  selectedFloor = floor;
  selectedTableId = null;
  document.getElementById("floorBtn1").className = floor === 1 ? "btn btn-primary" : "btn btn-ghost";
  document.getElementById("floorBtn2").className = floor === 2 ? "btn btn-primary" : "btn btn-ghost";
  renderTables();
}

function renderTables(){
  const grid = document.getElementById("tableGrid");
  grid.innerHTML = "";
  
  const maxTables = selectedFloor === 1 ? 20 : 30;
  const colsPerRow = 4;
  const rows = Math.ceil(maxTables / colsPerRow);
  
  for(let i = 1; i <= maxTables; i++){
    const btn = document.createElement("button");
    btn.className = "table-btn";
    btn.textContent = i;
    btn.onclick = () => selectTable(i);
    if(selectedTableId === i) btn.classList.add("selected");
    grid.appendChild(btn);
  }
}

function selectTable(tableNum){
  selectedTableId = tableNum;
  renderTables();
  document.getElementById("selectedTable").textContent = `${tableNum} (Lantai ${selectedFloor})`;
}

function updateSummary(){
  const cart = loadCart();
  const total = cart.reduce((a,x)=>a+(x.qty*x.price),0);
  const html = cart.map(it => `
    <div class="summary-row">
      <span>${it.name} × ${it.qty}</span>
      <span>${rupiah(it.qty * it.price)}</span>
    </div>
  `).join("") + `
    <div class="summary-row">
      <span>TOTAL</span>
      <span>${rupiah(total)}</span>
    </div>
  `;
  document.getElementById("checkoutSummary").innerHTML = html;
}

function requestPayment(){
  const customerName = document.getElementById("customerName").value.trim();
  if(!customerName){
    alert("Masukkan nama terlebih dahulu");
    return;
  }
  if(!selectedTableId){
    alert("Pilih nomor meja terlebih dahulu");
    return;
  }
  
  // Hide name, table, and summary sections
  document.getElementById("nameSection").style.display = "none";
  document.getElementById("tableSection").style.display = "none";
  document.getElementById("summarySection").style.display = "none";
  
  // Show QRIS section
  document.getElementById("qrisSection").style.display = "block";
  
  // Hide continue button and show payment done button
  document.getElementById("continueActions").style.display = "none";
  document.getElementById("afterQrisActions").style.display = "block";

  // Display QRIS image from static folder
  document.getElementById("qrisImage").src = "/static/images/QRIS Mockup.png";
}

function processPaymentFinalize(){
  // Disable button to prevent double clicks
  const btn = document.getElementById("paymentDoneBtn");
  if(btn) btn.disabled = true;
  const customerName = document.getElementById("customerName").value.trim();
  processPayment(customerName);
}

async function processPayment(customerName){
  const cart = loadCart();
  const payload = {
    source: "QR",
    table_id: selectedTableId,
    customer_name: customerName,
    items: cart.map(x => ({menu_id:x.menu_id, qty:x.qty})),
    payment_status: "PAID"
  };
  
  const res = await fetch("/api/order", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  
  if(!data.ok){
    alert("Gagal membuat pesanan: " + (data.error || "unknown"));
    return;
  }
  
  clearCart();
  window.location.href = "/receipt/" + data.order_id;
}

async function pollQueueNow(){
  const foodEl = document.getElementById("foodNow");
  const drinkEl = document.getElementById("drinkNow");
  if(!foodEl || !drinkEl) return;

  try{
    const res = await fetch("/api/queue-now");
    const data = await res.json();
    foodEl.textContent = data.food_now ?? "-";
    drinkEl.textContent = data.drink_now ?? "-";
  }catch(e){}
  setTimeout(pollQueueNow, 4000);
}

document.addEventListener("DOMContentLoaded", ()=>{
  renderCart();
  pollQueueNow();
});
