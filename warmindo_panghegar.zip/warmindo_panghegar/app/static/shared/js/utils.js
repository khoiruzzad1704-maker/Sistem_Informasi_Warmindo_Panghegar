// Tempat utilitas JavaScript bersama bila diperlukan.
