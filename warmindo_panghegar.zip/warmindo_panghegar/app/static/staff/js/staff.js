function fmtTime(ts){
  try{
    return new Date(ts).toLocaleTimeString("id-ID", {hour:"2-digit", minute:"2-digit"});
  }catch(e){
    return "-";
  }
}

function ticketHTML(order, withButtons=true){
  const tableCode = order.table_code || null;
  const meja = (order.table_number || tableCode) ? `${tableCode ? tableCode + ' ' : ''}${order.table_number ? '(#' + order.table_number + ')' : ''}` : "Tanpa meja";
  // Queue numbers are already shown as badges. Keeping a second text line
  // makes the queue number look duplicated, so we remove it.
  const total = "Rp " + Math.round(order.total_amount || 0).toLocaleString("id-ID");
  // choose time display: created_at for NEW, started_at for IN_PROGRESS (if available), updated_at otherwise
  let displayTs = order.created_at;
  if(order.status === 'IN_PROGRESS' && Array.isArray(order.progress)){
    // pick the earliest non-null started_at from progress rows
    const started = order.progress.map(p=>p.started_at).filter(x=>x).sort()[0];
    if(started) displayTs = started;
  }
  const itemsHtml = (order.items || []).map(i=> `<li>${i.qty}× ${i.name} <span class="muted">(${i.category || ''})</span></li>`).join("");
  // build queue badges (food/drink) to show prominently
  const qBadges = [];
  if(order.queue_no_food) qBadges.push(`<div class="queue-badge queue-food">${order.queue_no_food}</div>`);
  if(order.queue_no_drink) qBadges.push(`<div class="queue-badge queue-drink">${order.queue_no_drink}</div>`);
  return `
    <div class="ticket" data-order-id="${order.id}">
      <div class="ticketTop">
        <div>
          <div class="ticketCode">${order.order_code}</div>
          <div class="ticketMeta">${meja} • ${order.order_source} • ${fmtTime(displayTs)}</div>
          <div class="ticketMeta">Total: ${total}</div>
        </div>
        <div class="pill">${order.status}</div>
      </div>
      <div class="ticketBadges">${qBadges.join('')}</div>
      <div class="ticketItems">
        <ul class="item-list">${itemsHtml}</ul>
      </div>
      ${withButtons ? `
      <div class="actions">
        <button class="btn btn-warning" onclick="handleStatusChange(${order.id}, 'IN_PROGRESS', this)">Proses</button>
        <button class="btn btn-primary" onclick="handleStatusChange(${order.id}, 'READY', this)">Siap</button>
      </div>` : ""}
    </div>
  `;
}

function handleStatusChange(orderId, status, btnElem){
  try{
    const ticket = btnElem.closest('.ticket');
    if(!ticket) return;
    // optimistic UI: disable buttons and show quick feedback
    const actions = ticket.querySelectorAll('.actions button');
    const origTexts = [];
    actions.forEach(b=>{ origTexts.push(b.textContent); b.disabled = true; b.textContent = '...'; });
    const pill = ticket.querySelector('.pill');
    if(pill) pill.textContent = status;

    // move ticket to target column instantly
    const colProg = document.getElementById('colIN_PROGRESS');
    const colReady = document.getElementById('colREADY');
    if(status === 'IN_PROGRESS' && colProg) colProg.prepend(ticket);
    if(status === 'READY' && colReady) colReady.prepend(ticket);

    // fire API in background
    updateOrderStatus(orderId, status).then((data)=>{
      // if server returned canonical order, update ticket DOM from it
      if(data && data.order){
        try{
          const newTicketHtml = ticketHTML(data.order, true);
          // replace ticket element
          const wrapper = document.createElement('div'); wrapper.innerHTML = newTicketHtml;
          ticket.replaceWith(wrapper.firstElementChild);
        }catch(e){
          try{ pollKitchenBoard(); }catch(e){}
        }
      }else{
        try{ pollKitchenBoard(); }catch(e){}
      }
    }).catch(err=>{
      // on error, alert and re-sync
      console.error('status update failed', err);
      alert('Gagal memperbarui status pesanan. Menyinkronkan ulang.');
      try{ pollKitchenBoard(); }catch(e){}
    }).finally(()=>{
      // ensure any leftover buttons are enabled after sync
      const btns = document.querySelectorAll('.actions button');
      btns.forEach(b=> b.disabled = false);
    });
  }catch(e){
    console.error(e);
  }
}

async function updateOrderStatus(orderId, status){
  const res = await fetch(`/staff/api/orders/${orderId}/status`, {
    method: "POST",
    credentials: "same-origin",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({status})
  });
  const data = await res.json();
  if(!data || data.ok === false){
    throw new Error(data && data.error ? data.error : 'update failed');
  }
  // return the server response so callers can update UI from canonical data
  return data;
}

async function pollKitchenBoard(){
  const colNew = document.getElementById("colNEW");
  const colProg = document.getElementById("colIN_PROGRESS");
  const colReady = document.getElementById("colREADY");
  if(!colNew || !colProg || !colReady){ return; }

  try{
    const res = await fetch("/staff/api/board", { credentials: "same-origin" });
    const orders = await res.json();
    colNew.innerHTML = "";
    colProg.innerHTML = "";
    colReady.innerHTML = "";

    // enrich and order NEW queue: FCFS for food, SPT for drinks
    const newOrders = orders.filter(o=> o.status === "NEW");
    const progOrders = orders.filter(o=> o.status === "IN_PROGRESS");
    const readyOrders = orders.filter(o=> o.status === "READY");

    // Sort NEW orders by the earliest queue number (food/drink) so each order
    // only appears once in the "Masuk" column (no duplicates).
    const rankVal = (o)=>{
      const f = (o.queue_no_food == null) ? 1e9 : Number(o.queue_no_food);
      const d = (o.queue_no_drink == null) ? 1e9 : Number(o.queue_no_drink);
      return Math.min(f, d);
    };
    const sortedNew = [...newOrders].sort((a,b)=>{
      const ra = rankVal(a);
      const rb = rankVal(b);
      if(ra !== rb) return ra - rb;
      // tie-breaker: created_at
      try{ return new Date(a.created_at) - new Date(b.created_at); }catch(e){ return 0; }
    });

    colNew.innerHTML = '';
    if(sortedNew.length){
      colNew.innerHTML += `<div class="queueHeader">Antrian Masuk (NEW)</div>`;
      sortedNew.forEach(o=>{ colNew.innerHTML += ticketHTML(o, true); });
    }else{
      colNew.innerHTML = `<div class="tiny">Belum ada pesanan baru.</div>`;
    }

    progOrders.forEach(o=> colProg.innerHTML += ticketHTML(o, true));
    readyOrders.forEach(o=> colReady.innerHTML += ticketHTML(o, true));
  }catch(e){}

  setTimeout(pollKitchenBoard, 1000);
}

async function pollRunnerBoard(){
  const body = document.getElementById("runnerREADY");
  if(!body){ return; }

  try{
    const res = await fetch("/staff/api/board", { credentials: "same-origin" });
    const orders = await res.json();
    body.innerHTML = "";
    orders.filter(o => o.status === "READY").forEach(o=>{
      const meja = o.table_number ? `Meja ${o.table_number}` : "Tanpa meja";
      const total = "Rp " + Math.round(o.total_amount || 0).toLocaleString("id-ID");
      const html = `
        <div class="ticket">
          <div class="ticketTop">
            <div>
              <div class="ticketCode">${o.order_code}</div>
              <div class="ticketMeta">${meja} • ${fmtTime(o.created_at)}</div>
              <div class="ticketMeta">Total: ${total}</div>
            </div>
            <div class="pill">${o.status}</div>
          </div>
          <div class="actions">
            <button class="btn btn-primary" onclick="updateOrderStatus(${o.id}, 'DELIVERED')">Sudah Diantar</button>
          </div>
        </div>
      `;
      body.innerHTML += html;
    });
  }catch(e){}

  setTimeout(pollRunnerBoard, 1000);
}

let chartSales, chartTopMenus, chartMenuPrep;

async function loadStats(){
  const canvasSales = document.getElementById("chartSales");
  const canvasTop = document.getElementById("chartTopMenus");
  const canvasMenuPrep = document.getElementById("chartMenuPrep");
  if(!canvasSales || !canvasTop){ return; }

  try{
    const res = await fetch("/staff/api/stats", { credentials: "same-origin" });
    const data = await res.json();

    const labelsSales = data.sales.labels;
    const valuesSales = data.sales.values;
    const ordersSales = data.sales.orders;

    const labelsTop = data.topMenus.labels;
    const valuesTop = data.topMenus.values;

    const labelsPrep = (data.menuPrep || {}).labels || [];
    const valuesPrep = (data.menuPrep || {}).values || [];
    const qtyPrep = (data.menuPrep || {}).qty || [];

    const ctx1 = canvasSales.getContext("2d");
    chartSales = new Chart(ctx1, {
      type: "bar",
      data: {
        labels: labelsSales,
        datasets: [
          { label: "Penjualan (Rp)", data: valuesSales, yAxisID: "y" },
          { label: "Jumlah Pesanan", data: ordersSales, type:"line", yAxisID:"y1" }
        ]
      },
      options:{
        responsive:true,
        scales:{
          y:{position:"left"},
          y1:{position:"right", grid:{drawOnChartArea:false}}
        }
      }
    });

    const ctx2 = canvasTop.getContext("2d");
    chartTopMenus = new Chart(ctx2, {
      type: "doughnut",
      data: {
        labels: labelsTop,
        datasets: [{ data: valuesTop }]
      },
      options:{responsive:true, plugins:{legend:{position:"bottom"}}}
    });

    // Chart: menu prep time (avg minutes per menu) - optional (only on kitchen dashboard)
    if(canvasMenuPrep){
      const ctx3 = canvasMenuPrep.getContext("2d");
      chartMenuPrep = new Chart(ctx3, {
        type: "bar",
        data: {
          labels: labelsPrep,
          datasets: [{ label: "Rata-rata waktu siap (menit)", data: valuesPrep }]
        },
        options:{
          responsive:true,
          plugins:{
            tooltip:{
              callbacks:{
                afterLabel: (ctx)=>{
                  const i = ctx.dataIndex;
                  const q = qtyPrep[i] != null ? qtyPrep[i] : "-";
                  return `Total pesanan: ${q}`;
                }
              }
            },
            legend:{display:true}
          }
        }
      });
    }

    if(data.prep){
      const elF = document.getElementById("avgFood");
      const elD = document.getElementById("avgDrink");
      if(elF) elF.textContent = data.prep.food_min;
      if(elD) elD.textContent = data.prep.drink_min;
    }
  }catch(e){}
}

async function loadInventory(){
  const tableBody = document.querySelector("#invTable tbody");
  const canvasInv = document.getElementById("chartInventory");
  if(!tableBody || !canvasInv){ return; }

  try{
    const res = await fetch("/manager/api/inventory", { credentials: "same-origin" });
    const rows = await res.json();
    tableBody.innerHTML = "";

    const labels = [];
    const stock = [];
    const rop = [];

    rows.forEach(r=>{
      labels.push(r.name);
      stock.push(r.stock_qty);
      rop.push(r.ROP);

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${r.name}</td>
        <td>${r.stock_qty.toFixed(1)} ${r.unit}</td>
        <td>${r.EOQ.toFixed(1)}</td>
        <td>${r.ROP.toFixed(1)}</td>
        <td>${r.need_reorder ? "<span style='color:#f97316;'>Pesan ulang</span>" : "<span style='color:#22c55e;'>Aman</span>"}</td>
      `;
      tableBody.appendChild(tr);
    });

    const ctx = canvasInv.getContext("2d");
    new Chart(ctx,{
      type:"bar",
      data:{
        labels,
        datasets:[
          {label:"Stok", data:stock},
          {label:"ROP", data:rop}
        ]
      },
      options:{responsive:true}
    });
  }catch(e){}
}

document.addEventListener("DOMContentLoaded", ()=>{
  if(document.getElementById("colNEW")) pollKitchenBoard();
  if(document.getElementById("runnerREADY")) pollRunnerBoard();
  if(document.getElementById("chartSales")) loadStats();
  if(document.getElementById("chartInventory")) loadInventory();
  if(document.getElementById("purchaseForm")) initPurchaseUI();
});

// ===== Manager: Purchase (Pembelian Bahan Baku) =====

function fmtDateTime(ts){
  try{
    return new Date(ts).toLocaleString("id-ID", {year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit"});
  }catch(e){
    return ts || "-";
  }
}

async function loadIngredientsForPurchase(){
  const sel = document.getElementById("ingredientSelect");
  const unitCostEl = document.getElementById("unitCost");
  if(!sel) return;

  sel.innerHTML = "<option value=''>Memuat...</option>";
  try{
    const res = await fetch("/manager/api/ingredients", { credentials: "same-origin" });
    const rows = await res.json();
    if(!Array.isArray(rows) || !rows.length){
      sel.innerHTML = "<option value=''>Tidak ada bahan</option>";
      return;
    }
    sel.innerHTML = "<option value=''>Pilih bahan...</option>";
    rows.forEach(r=>{
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = `${r.name} (${r.unit})`;
      opt.dataset.unit = r.unit;
      opt.dataset.purchasePrice = r.purchase_price ?? "";
      sel.appendChild(opt);
    });

    // auto fill harga/unit from master data (if available)
    sel.addEventListener('change', ()=>{
      const opt = sel.options[sel.selectedIndex];
      const price = opt ? opt.dataset.purchasePrice : "";
      if(unitCostEl && price && Number(price) > 0) unitCostEl.value = Number(price);
    }, { once:false });
  }catch(e){
    sel.innerHTML = "<option value=''>Gagal memuat</option>";
  }
}

async function loadPurchaseRecap(){
  const tbody = document.querySelector("#purchaseRecap tbody");
  if(!tbody) return;
  tbody.innerHTML = "<tr><td colspan='6' class='tiny'>Memuat...</td></tr>";

  try{
    const res = await fetch("/manager/api/purchase-items", { credentials: "same-origin" });
    const rows = await res.json();
    tbody.innerHTML = "";

    if(!Array.isArray(rows) || !rows.length){
      tbody.innerHTML = "<tr><td colspan='6' class='tiny'>Belum ada data pembelian.</td></tr>";
      return;
    }

    rows.forEach(r=>{
      const tr = document.createElement('tr');
      const total = Math.round(Number(r.total_price || 0));
      tr.innerHTML = `
        <td>#${r.purchase_id} <span class="tiny">(${r.purchase_code || '-'})</span></td>
        <td>${fmtDateTime(r.purchased_at)}</td>
        <td>${r.ingredient_name || '-'}</td>
        <td>Rp ${Math.round(Number(r.unit_cost || 0)).toLocaleString('id-ID')}</td>
        <td>${Number(r.qty || 0).toFixed(2)}</td>
        <td>Rp ${total.toLocaleString('id-ID')}</td>
      `;
      tbody.appendChild(tr);
    });
  }catch(e){
    tbody.innerHTML = "<tr><td colspan='6' class='tiny'>Gagal memuat rekap pembelian.</td></tr>";
  }
}

async function handlePurchaseSubmit(evt){
  evt.preventDefault();
  const msg = document.getElementById("purchaseMsg");
  const supplier = document.getElementById("supplierName");
  const sel = document.getElementById("ingredientSelect");
  const unitCostEl = document.getElementById("unitCost");
  const qtyEl = document.getElementById("qty");

  const ingredientId = Number(sel?.value || 0);
  const unitCost = Number(unitCostEl?.value || 0);
  const qty = Number(qtyEl?.value || 0);

  if(msg) msg.textContent = "";
  if(!ingredientId){ if(msg) msg.textContent = "Pilih bahan dulu."; return; }
  if(qty <= 0){ if(msg) msg.textContent = "Quantity harus > 0."; return; }
  if(unitCost <= 0){ if(msg) msg.textContent = "Harga/unit harus > 0."; return; }

  try{
    if(msg) msg.textContent = "Menyimpan...";
    const res = await fetch("/manager/api/purchases", {
      method: "POST",
      credentials: "same-origin",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        supplier_name: supplier?.value || null,
        items: [{ ingredient_id: ingredientId, qty, unit_cost: unitCost }]
      })
    });
    const data = await res.json();
    if(!data || data.ok === false){
      throw new Error(data?.error || "Gagal menyimpan pembelian");
    }
    if(msg) msg.textContent = `Tersimpan (${data.purchase_code}).`;
    if(qtyEl) qtyEl.value = "";

    // Refresh recap + inventory table
    try{ await loadPurchaseRecap(); }catch(e){}
    try{ await loadInventory(); }catch(e){}
  }catch(e){
    if(msg) msg.textContent = `Gagal: ${e.message || e}`;
  }
}

function initPurchaseUI(){
  const form = document.getElementById("purchaseForm");
  if(!form) return;
  form.addEventListener('submit', handlePurchaseSubmit);
  loadIngredientsForPurchase();
  loadPurchaseRecap();
}
