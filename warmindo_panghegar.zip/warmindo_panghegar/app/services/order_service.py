import uuid
from app.db import execute, commit, rollback, query_one
from app.models.menu_model import get_menu_by_id
from app.models.order_model import (
    insert_order,
    insert_order_item,
    update_order_total,
    ensure_progress_row,
)
from app.services.queue_service import next_food_queue_number_today, next_drink_queue_number_today

def _generate_order_code() -> str:
    """Membuat kode pesanan unik."""
    return "ORD-" + uuid.uuid4().hex[:8].upper()

def create_order_from_payload(payload: dict) -> dict:
    """Membuat pesanan baru dari payload JSON website pelanggan."""
    try:
        order_code = _generate_order_code()

        # Resolve table identifier: payload may send dining_tables.id or a table_number.
        raw_table = payload.get("table_id")
        resolved_table_id = None
        if raw_table is not None:
            try:
                # try as id
                row = query_one("SELECT id FROM dining_tables WHERE id=%s AND is_active=1", (int(raw_table),))
                if row:
                    resolved_table_id = row["id"]
                else:
                    # try as table_number
                    row = query_one("SELECT id FROM dining_tables WHERE table_number=%s AND is_active=1", (int(raw_table),))
                    if row:
                        resolved_table_id = row["id"]
            except Exception:
                resolved_table_id = None

        order_id = insert_order(
            order_code,
            payload.get("source", "QR"),
            resolved_table_id,
            payload.get("customer_name"),
            payment_status=payload.get("payment_status", "UNPAID"),
            payment_method=payload.get("payment_method"),
        )

        total = 0.0
        has_food = False
        has_drink = False

        for item in payload.get("items", []):
            menu = get_menu_by_id(int(item["menu_id"]))
            qty = int(item["qty"])
            line = float(menu["price"]) * qty
            total += line

            if menu["category"] == "MAKANAN":
                has_food = True
            else:
                has_drink = True

            insert_order_item(
                order_id,
                menu["id"],
                qty,
                float(menu["price"]),
                menu["category"],
                int(menu["prep_time_sec"]),
            )

        update_order_total(order_id, total)

        if has_food:
            ensure_progress_row(order_id, "MAKANAN")
        if has_drink:
            ensure_progress_row(order_id, "MINUMAN")

        # Set nomor antrian secepat mungkin agar struk pelanggan tampil tanpa delay lama.
        q_food = next_food_queue_number_today() if has_food else None
        q_drink = next_drink_queue_number_today() if has_drink else None
        execute("UPDATE orders SET queue_no_food=%s, queue_no_drink=%s WHERE id=%s", (q_food, q_drink, order_id))
        commit()

        return {"ok": True, "order_id": order_id, "order_code": order_code}
    except Exception as e:
        rollback()
        return {"ok": False, "error": str(e)}

def mark_order_delivered(order_id: int) -> dict:
    """Mengatur status order menjadi DELIVERED dan mengurangi stok."""
    from app.models.order_model import update_order_status
    from app.services.inventory_service import consume_stock_for_order

    try:
        update_order_status(order_id, "DELIVERED", payment_status="PAID")
        consume_stock_for_order(order_id)
        commit()
        return {"ok": True}
    except Exception as e:
        rollback()
        return {"ok": False, "error": str(e)}
