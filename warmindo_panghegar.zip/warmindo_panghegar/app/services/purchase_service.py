import uuid
from app.db import commit, rollback
from app.models.purchase_model import create_purchase, add_purchase_item, update_purchase_total
from app.models.inventory_model import update_stock

def _purchase_code() -> str:
    """Membuat kode pembelian unik."""
    return "PUR-" + uuid.uuid4().hex[:8].upper()

def create_purchase_with_items(payload: dict) -> dict:
    """Membuat pembelian baru dan menambah stok bahan baku."""
    try:
        code = _purchase_code()
        purchase_id = create_purchase(code, payload.get("supplier_name"))

        for item in payload.get("items", []):
            ing_id = int(item["ingredient_id"])
            qty = float(item["qty"])
            unit_cost = float(item["unit_cost"])
            add_purchase_item(purchase_id, ing_id, qty, unit_cost)
            update_stock(ing_id, qty, "PURCHASE", purchase_id, "Pembelian bahan")

        update_purchase_total(purchase_id)
        commit()
        return {"ok": True, "purchase_id": purchase_id, "purchase_code": code}
    except Exception as e:
        rollback()
        return {"ok": False, "error": str(e)}
