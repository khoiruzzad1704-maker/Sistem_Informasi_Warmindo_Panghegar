import math
from app.db import query_all
from app.models.inventory_model import list_ingredients, recipe_for_menu, update_stock

def calc_eoq(D: float, S: float, H: float) -> float:
    """Menghitung Economic Order Quantity (EOQ)."""
    if D <= 0 or S <= 0 or H <= 0:
        return 0.0
    return math.sqrt((2 * D * S) / H)

def calc_rop(daily_demand: float, lead_time_days: int, safety_stock: float) -> float:
    """Menghitung Reorder Point (ROP)."""
    if daily_demand < 0 or lead_time_days < 0 or safety_stock < 0:
        return 0.0
    return (daily_demand * lead_time_days) + safety_stock

def consume_stock_for_order(order_id: int) -> None:
    """Mengurangi stok bahan baku berdasarkan item dalam satu order."""
    items = query_all(
        """SELECT oi.menu_id, oi.qty
            FROM order_items oi
            WHERE oi.order_id=%s""",
        (order_id,),
    )
    needed = {}
    for it in items:
        recipe = recipe_for_menu(it["menu_id"])
        for r in recipe:
            ing = r["ingredient_id"]
            qty_need = float(r["qty_needed"]) * it["qty"]
            needed[ing] = needed.get(ing, 0.0) + qty_need

    for ing_id, total_need in needed.items():
        update_stock(ing_id, -total_need, "SALE", order_id, "Konsumsi order")

def inventory_recommendations():
    """Menghasilkan rekomendasi EOQ & ROP untuk seluruh bahan baku."""
    rows = list_ingredients()
    recs = []
    for r in rows:
        daily = float(r["daily_demand_avg"])
        D = daily * 30.0
        S = float(r["ordering_cost"])
        H = float(r["holding_cost"])
        eoq = calc_eoq(D, S, H)
        rop = calc_rop(daily, int(r["lead_time_days"]), float(r["safety_stock"]))
        stock = float(r["stock_qty"])
        recs.append({
            "id": r["id"],
            "name": r["name"],
            "unit": r["unit"],
            "stock_qty": stock,
            "EOQ": round(eoq, 2),
            "ROP": round(rop, 2),
            "need_reorder": stock <= rop,
        })
    return recs
