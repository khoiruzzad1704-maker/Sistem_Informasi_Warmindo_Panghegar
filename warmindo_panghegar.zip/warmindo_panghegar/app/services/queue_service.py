from app.db import query_all, execute, commit

def next_food_queue_number_today() -> int:
    """Mengambil nomor antrian makanan berikutnya (FCFS) untuk hari ini."""
    row = query_all(
        """SELECT COALESCE(MAX(queue_no_food),0) AS mx
            FROM orders
            WHERE DATE(created_at) = CURDATE()"""
    )[0]
    return int(row["mx"]) + 1


def next_drink_queue_number_today() -> int:
    """Mengambil nomor antrian minuman berikutnya (cepat, tanpa recalc).

    Catatan: untuk performa (agar struk pelanggan muncul tanpa delay panjang),
    penomoran minuman dibuat sederhana seperti FCFS (berdasarkan max queue_no_drink).
    """
    row = query_all(
        """SELECT COALESCE(MAX(queue_no_drink),0) AS mx
            FROM orders
            WHERE DATE(created_at) = CURDATE()"""
    )[0]
    return int(row["mx"]) + 1

def recalc_drink_queue_numbers_today() -> None:
    """Menghitung ulang nomor antrian minuman berdasarkan aturan SPT."""
    jobs = query_all(
        """SELECT
                o.id AS order_id,
                SUM(oi.qty * oi.prep_time_sec_snapshot) AS total_prep
            FROM orders o
            JOIN order_items oi ON oi.order_id = o.id
            WHERE DATE(o.created_at) = CURDATE()
              AND oi.category_snapshot='MINUMAN'
              AND o.status IN ('NEW','IN_PROGRESS')
            GROUP BY o.id
            ORDER BY total_prep ASC, o.created_at ASC"""
    )
    q = 1
    for job in jobs:
        execute("UPDATE orders SET queue_no_drink=%s WHERE id=%s", (q, job["order_id"]))
        q += 1
    commit()


def recalc_food_queue_numbers_today() -> None:
    """Recalculate food queue numbers (FCFS) for today's orders in NEW/IN_PROGRESS."""
    jobs = query_all(
        """SELECT DISTINCT o.id AS order_id, o.created_at
            FROM orders o
            JOIN order_items oi ON oi.order_id = o.id
            WHERE DATE(o.created_at) = CURDATE()
              AND oi.category_snapshot='MAKANAN'
              AND o.status IN ('NEW','IN_PROGRESS')
            ORDER BY o.created_at ASC"""
    )
    q = 1
    # clear all today's food queue numbers first
    execute("UPDATE orders SET queue_no_food=NULL WHERE DATE(created_at)=CURDATE()")
    for job in jobs:
        execute("UPDATE orders SET queue_no_food=%s WHERE id=%s", (q, job["order_id"]))
        q += 1
    commit()
