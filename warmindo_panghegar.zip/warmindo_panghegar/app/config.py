import os

class Config:
    """Konfigurasi utama aplikasi."""

    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")

    # Konfigurasi database MySQL (XAMPP)
    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASS = os.getenv("DB_PASS", "")
    DB_NAME = os.getenv("DB_NAME", "warmindo_panghegar")
