from flask import Flask
from .config import Config
from .db import close_db

def create_app():
    """Application factory: membuat dan mengkonfigurasi instance Flask."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # Tutup koneksi DB di akhir setiap request
    app.teardown_appcontext(close_db)

    # Registrasi blueprint
    from .routes.customer_routes import customer_bp
    from .routes.cashier_routes import cashier_bp
    from .routes.staff_routes import staff_bp
    from .routes.manager_routes import manager_bp
    from .routes.owner_routes import owner_bp
    from .routes.auth_routes import auth_bp

    app.register_blueprint(customer_bp)
    app.register_blueprint(cashier_bp, url_prefix="/staff/cashier")
    app.register_blueprint(staff_bp, url_prefix="/staff")
    app.register_blueprint(manager_bp, url_prefix="/manager")
    app.register_blueprint(owner_bp, url_prefix="/owner")
    app.register_blueprint(auth_bp, url_prefix="/auth")

    return app
