from flask import Blueprint, render_template
from app.models.menu_model import get_active_menus
from app.models.order_model import get_order_with_items, queue_now
from flask import current_app, send_file, make_response
import io
try:
    import pdfkit
    _HAS_PDFKIT = True
except Exception:
    _HAS_PDFKIT = False

cashier_bp = Blueprint("cashier", __name__)

@cashier_bp.get("/")
def cashier_menu():
    """Halaman menu untuk kasir dengan opsi pembayaran tunai/non-tunai."""
    menus = get_active_menus()
    now = queue_now()
    return render_template("cashier/menu.html", menus=menus, now=now)

@cashier_bp.get("/receipt/<int:order_id>")
def cashier_receipt(order_id: int):
    """Halaman struk kasir dengan opsi cetak."""
    order, items = get_order_with_items(order_id)
    now = queue_now()
    return render_template("cashier/receipt.html", order=order, items=items, now=now)


@cashier_bp.get('/receipt/<int:order_id>/pdf')
def cashier_receipt_pdf(order_id: int):
    """Return PDF of the receipt. Uses pdfkit if available; otherwise returns HTML page."""
    order, items = get_order_with_items(order_id)
    now = queue_now()
    rendered = render_template('cashier/receipt.html', order=order, items=items, now=now)

    if not _HAS_PDFKIT:
        # pdfkit not installed — return HTML with a helpful message
        resp = make_response(rendered)
        resp.headers['X-PDF-Generation'] = 'unavailable'
        return resp

    # try to generate PDF via pdfkit. Expect wkhtmltopdf available on system.
    options = {
        'page-width': '80mm',
        'margin-top': '4mm',
        'margin-bottom': '4mm',
        'margin-left': '4mm',
        'margin-right': '4mm',
        'encoding': 'UTF-8',
    }
    try:
        pdf_bytes = pdfkit.from_string(rendered, False, options=options)
        return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf', as_attachment=True,
                         download_name=f'struk-{order.get("order_code","{order_id}")}.pdf')
    except Exception:
        resp = make_response(rendered)
        resp.headers['X-PDF-Generation'] = 'failed'
        return resp
