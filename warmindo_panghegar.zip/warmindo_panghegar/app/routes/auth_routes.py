from flask import Blueprint, render_template, request, redirect, url_for, session

# Hardcoded internal credentials requested by user
INTERNAL_USERNAME = "warmindopanghegar"
INTERNAL_PASSWORD = "cuanterus123"

auth_bp = Blueprint("auth", __name__)

@auth_bp.get("/login")
def login_page():
    """Halaman login placeholder (belum ada autentikasi)."""
    return render_template("auth/login.html")


@auth_bp.post("/login")
def login_post():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if username == INTERNAL_USERNAME and password == INTERNAL_PASSWORD:
        session["user"] = username
        return redirect(url_for("owner.menu_manage"))
    return render_template("auth/login.html", error="Kredensial salah")


@auth_bp.get('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('auth.login_page'))
