from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, current_app
from app.models.order_model import board_orders, update_order_status, get_order_with_items
from app.services.order_service import mark_order_delivered
from app.models.finance_model import dashboard_stats
from app.db import query_one, query_all

staff_bp = Blueprint("staff", __name__)


@staff_bp.before_request
def _staff_require_login():
    if not session.get("user"):
        if request.is_json:
            return jsonify({"error": "unauthorized"}), 401
        return redirect(url_for('auth.login_page'))

@staff_bp.get("/kitchen")
def kitchen_board():
    """Dashboard dapur: melihat pesanan NEW/IN_PROGRESS/READY."""
    return render_template("staff/dashboard_kitchen.html")

@staff_bp.get("/runner")
def runner_board():
    """Dashboard runner: fokus pesanan READY untuk diantar."""
    return render_template("staff/dashboard_runner.html")

@staff_bp.get("/api/board")
def api_board():
    """API data board untuk kitchen & runner."""
    raw = board_orders()
    enriched = []
    for o in raw:
        # get full order header/items and progress rows, compute prep time sums
        header, items = get_order_with_items(o["id"])
        progress_rows = query_all("SELECT category, status, started_at, finished_at FROM order_progress WHERE order_id=%s", (o["id"],))
        # items come with fields including category_snapshot and prep_time_sec_snapshot
        total_prep_food = 0
        total_prep_drink = 0
        formatted_items = []
        for it in items:
            cat = (it.get("category_snapshot") or "").lower()
            prep = int(it.get("prep_time_sec_snapshot") or 0) * int(it.get("qty") or 1)
            if "minum" in cat or "drink" in cat or "beverage" in cat:
                total_prep_drink += prep
            else:
                total_prep_food += prep
            formatted_items.append({
                "name": it.get("name"),
                "qty": it.get("qty"),
                "unit_price": it.get("unit_price"),
                "category": it.get("category_snapshot"),
                "prep_time_sec": it.get("prep_time_sec_snapshot"),
            })

        # merge header (canonical) and our computed values
        merged = dict(header or o)
        merged["progress"] = progress_rows
        merged.update({
            "items": formatted_items,
            "total_prep_food_sec": total_prep_food,
            "total_prep_drink_sec": total_prep_drink,
        })
        enriched.append(merged)

    return jsonify(enriched)

@staff_bp.post("/api/orders/<int:order_id>/status")
def api_update_status(order_id: int):
    """API untuk mengubah status pesanan dari dashboard staff."""
    body = request.get_json(force=True)
    status = body.get("status")
    debug = body.get("debug") or request.args.get("debug") == '1'

    # pre-count queues for debug
    before_food = None
    before_drink = None
    try:
        before_food = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_food IS NOT NULL")["c"]
        before_drink = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_drink IS NOT NULL")["c"]
    except Exception:
        before_food = before_drink = None

    current_app.logger.info(f"Staff {session.get('user')} updating order {order_id} -> {status}")

    if status == "DELIVERED":
        res = mark_order_delivered(order_id)
        header, items = get_order_with_items(order_id)
        resp = dict(header or {})
        resp["items"] = items
        result = {**res, "order": resp}
    else:
        try:
            update_order_status(order_id, status)
            header, items = get_order_with_items(order_id)
            resp = dict(header or {})
            resp["items"] = items
            result = {"ok": True, "order": resp}
        except Exception as e:
            current_app.logger.exception("Failed to update order status")
            return jsonify({"ok": False, "error": str(e)}), 500

    # post-count queues for debug
    after_food = None
    after_drink = None
    try:
        after_food = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_food IS NOT NULL")["c"]
        after_drink = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_drink IS NOT NULL")["c"]
    except Exception:
        after_food = after_drink = None

    if debug:
        result["debug"] = {
            "before": {"food_count": before_food, "drink_count": before_drink},
            "after": {"food_count": after_food, "drink_count": after_drink},
        }

    return jsonify(result)

@staff_bp.get("/api/stats")
def api_stats():
    """API statistik untuk grafik dashboard dapur."""
    return jsonify(dashboard_stats())


@staff_bp.post("/api/recalc-queues")
def api_recalc_queues():
    """Admin endpoint: force recalculation of today's queues for food and drink."""
    try:
        from app.services.queue_service import recalc_food_queue_numbers_today, recalc_drink_queue_numbers_today
        recalc_food_queue_numbers_today()
        recalc_drink_queue_numbers_today()
        f_count = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_food IS NOT NULL")["c"]
        d_count = query_one("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() AND queue_no_drink IS NOT NULL")["c"]
        current_app.logger.info(f"Manual recalculation performed by {session.get('user')}: food={f_count}, drink={d_count}")
        return jsonify({"ok": True, "recalculated": {"food_count": f_count, "drink_count": d_count}})
    except Exception as e:
        current_app.logger.exception("Failed to recalc queues")
        return jsonify({"ok": False, "error": str(e)}), 500
