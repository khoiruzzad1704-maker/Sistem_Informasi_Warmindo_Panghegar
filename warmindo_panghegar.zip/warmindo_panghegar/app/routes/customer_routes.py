from flask import Blueprint, render_template, request, jsonify, redirect
from app.models.menu_model import get_active_menus
from app.models.table_model import get_table_by_code
from app.models.order_model import get_order_with_items, queue_now
from app.services.order_service import create_order_from_payload

customer_bp = Blueprint("customer", __name__)

@customer_bp.get("/")
def customer_menu():
    """Website pelanggan: daftar menu ala ecommerce + keranjang."""
    table_code = request.args.get("table_code")
    table = get_table_by_code(table_code) if table_code else None
    menus = get_active_menus()
    now = queue_now()
    return render_template("customer/menu.html", table=table, menus=menus, now=now)

@customer_bp.get("/operasional")
def operasional_redirect():
    """Redirect ke halaman kasir."""
    return redirect("/staff/cashier/")

@customer_bp.post("/api/order")
def api_order():
    """API untuk membuat pesanan baru."""
    payload = request.get_json(force=True)
    result = create_order_from_payload(payload)
    return jsonify(result)

@customer_bp.get("/api/queue-now")
def api_queue_now():
    """API untuk mengambil antrian yang sedang diproses."""
    return jsonify(queue_now())

@customer_bp.get("/receipt/<int:order_id>")
def receipt(order_id: int):
    """Halaman struk setelah checkout."""
    order, items = get_order_with_items(order_id)
    now = queue_now()
    return render_template("customer/receipt.html", order=order, items=items, now=now)

@customer_bp.get("/order-history")
def order_history():
    """Halaman riwayat pesanan pelanggan."""
    return render_template("customer/order_history.html")
