from io import BytesIO
from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, session, send_file

from openpyxl import Workbook
from openpyxl.utils import get_column_letter

from app.models.menu_model import get_all_menus, update_menu_price, update_menu_active
from app.models.finance_model import profit_summary
from app.services.inventory_service import inventory_recommendations
from app.db import query_all
from app.db import commit

owner_bp = Blueprint("owner", __name__)


@owner_bp.before_request
def _owner_require_login():
    if not session.get("user"):
        return redirect(url_for("auth.login_page"))

@owner_bp.get("/menu")
def menu_manage():
    """Halaman owner: kelola menu & harga."""
    menus = get_all_menus()
    return render_template("owner/menu_manage.html", menus=menus)

@owner_bp.post("/menu/update")
def menu_update():
    """Proses form perubahan harga/aktif menu."""
    menu_id = int(request.form["menu_id"])
    price = float(request.form["price"])
    is_active = int(request.form.get("is_active", "1"))
    update_menu_price(menu_id, price)
    update_menu_active(menu_id, is_active)
    commit()
    return redirect(url_for("owner.menu_manage"))

@owner_bp.get("/finance")
def finance_page():
    """Halaman laporan keuangan sederhana."""
    date_from = request.args.get("from", "2025-01-01")
    date_to = request.args.get("to", "2030-01-01")
    summary = profit_summary(date_from, date_to)

    # Detail penjualan (termasuk menu yang terjual)
    sales_items = query_all(
        """SELECT
               o.order_code,
               o.created_at,
               oi.category_snapshot,
               m.name AS menu_name,
               oi.qty,
               oi.unit_price,
               (oi.qty * oi.unit_price) AS subtotal
           FROM orders o
           JOIN order_items oi ON oi.order_id = o.id
           JOIN menus m ON m.id = oi.menu_id
           WHERE o.status='DELIVERED'
             AND DATE(o.created_at) BETWEEN %s AND %s
           ORDER BY o.created_at ASC, o.order_code ASC, m.name ASC""",
        (date_from, date_to),
    )

    # Update bahan baku (berkurang karena penjualan) - diambil dari inventory_logs ref_type SALE
    ingredient_usage = query_all(
        """SELECT
               il.created_at,
               o.order_code,
               i.name AS ingredient_name,
               i.unit,
               il.qty_change,
               il.note
           FROM inventory_logs il
           JOIN ingredients i ON i.id = il.ingredient_id
           LEFT JOIN orders o ON o.id = il.ref_id AND il.ref_type='SALE'
           WHERE il.ref_type='SALE'
             AND DATE(il.created_at) BETWEEN %s AND %s
           ORDER BY il.created_at ASC""",
        (date_from, date_to),
    )

    # Detail pembelian bahan baku
    purchase_items = query_all(
        """SELECT
               p.purchase_code,
               p.purchased_at,
               p.supplier_name,
               i.name AS ingredient_name,
               i.unit,
               pi.qty,
               pi.unit_cost,
               (pi.qty * pi.unit_cost) AS total_line
           FROM purchase_items pi
           JOIN purchases p ON p.id = pi.purchase_id
           JOIN ingredients i ON i.id = pi.ingredient_id
           WHERE DATE(p.purchased_at) BETWEEN %s AND %s
           ORDER BY p.purchased_at ASC, p.purchase_code ASC""",
        (date_from, date_to),
    )
    return render_template(
        "owner/finance_report.html",
        summary=summary,
        date_from=date_from,
        date_to=date_to,
        sales_items=sales_items,
        ingredient_usage=ingredient_usage,
        purchase_items=purchase_items,
    )


@owner_bp.get("/finance/download")
def finance_download():
    """Download laporan Excel: detail cashflow + ketersediaan stok."""
    date_from = request.args.get("from", "2025-01-01")
    date_to = request.args.get("to", "2030-01-01")

    # === Data Cashflow ===
    sales = query_all(
        """SELECT order_code, created_at, total_amount, order_source
           FROM orders
           WHERE status='DELIVERED'
             AND DATE(created_at) BETWEEN %s AND %s
           ORDER BY created_at ASC""",
        (date_from, date_to),
    )
    purchases = query_all(
        """SELECT purchase_code, purchased_at, total_cost, supplier_name
           FROM purchases
           WHERE DATE(purchased_at) BETWEEN %s AND %s
           ORDER BY purchased_at ASC""",
        (date_from, date_to),
    )

    # === Detail penjualan (menu terjual) ===
    sales_items = query_all(
        """SELECT
               o.order_code,
               o.created_at,
               oi.category_snapshot,
               m.name AS menu_name,
               oi.qty,
               oi.unit_price,
               (oi.qty * oi.unit_price) AS subtotal
           FROM orders o
           JOIN order_items oi ON oi.order_id = o.id
           JOIN menus m ON m.id = oi.menu_id
           WHERE o.status='DELIVERED'
             AND DATE(o.created_at) BETWEEN %s AND %s
           ORDER BY o.created_at ASC, o.order_code ASC, m.name ASC""",
        (date_from, date_to),
    )

    # === Pemakaian bahan baku (stok berkurang setelah penjualan) ===
    ingredient_usage = query_all(
        """SELECT
               il.created_at,
               o.order_code,
               i.name AS ingredient_name,
               i.unit,
               il.qty_change,
               il.note
           FROM inventory_logs il
           JOIN ingredients i ON i.id = il.ingredient_id
           LEFT JOIN orders o ON o.id = il.ref_id AND il.ref_type='SALE'
           WHERE il.ref_type='SALE'
             AND DATE(il.created_at) BETWEEN %s AND %s
           ORDER BY il.created_at ASC""",
        (date_from, date_to),
    )

    # === Detail pembelian (line items) ===
    purchase_items = query_all(
        """SELECT
               p.purchase_code,
               p.purchased_at,
               p.supplier_name,
               i.name AS ingredient_name,
               i.unit,
               pi.qty,
               pi.unit_cost,
               (pi.qty * pi.unit_cost) AS total_line
           FROM purchase_items pi
           JOIN purchases p ON p.id = pi.purchase_id
           JOIN ingredients i ON i.id = pi.ingredient_id
           WHERE DATE(p.purchased_at) BETWEEN %s AND %s
           ORDER BY p.purchased_at ASC, p.purchase_code ASC""",
        (date_from, date_to),
    )

    # === Workbook ===
    wb = Workbook()

    # Sheet 1: Cashflow (row-level)
    ws = wb.active
    ws.title = "Cashflow"
    ws.append(["Tanggal", "Tipe", "Kode", "Sumber/Supplier", "Jumlah (Rp)", "Keterangan"])

    cash_rows = []
    for s in (sales or []):
        cash_rows.append({
            "ts": s["created_at"],
            "type": "SALE",
            "code": s["order_code"],
            "party": s.get("order_source") or "-",
            "amount": float(s.get("total_amount") or 0),
            "note": "Penjualan (DELIVERED)",
        })
    for p in (purchases or []):
        cash_rows.append({
            "ts": p["purchased_at"],
            "type": "PURCHASE",
            "code": p["purchase_code"],
            "party": p.get("supplier_name") or "-",
            "amount": -float(p.get("total_cost") or 0),
            "note": "Pembelian bahan baku",
        })
    cash_rows.sort(key=lambda r: r["ts"] or datetime.min)

    for r in cash_rows:
        ws.append([
            r["ts"],
            r["type"],
            r["code"],
            r["party"],
            r["amount"],
            r["note"],
        ])

    # auto width (simple)
    for col in range(1, 7):
        ws.column_dimensions[get_column_letter(col)].width = 18

    # Sheet 2: Daily summary
    ws2 = wb.create_sheet("Ringkasan Harian")
    ws2.append(["Tanggal", "Total Penjualan", "Total Pembelian", "Net Cashflow"])

    daily_sales = query_all(
        """SELECT DATE(created_at) AS day, COALESCE(SUM(total_amount),0) AS total
           FROM orders
           WHERE status='DELIVERED'
             AND DATE(created_at) BETWEEN %s AND %s
           GROUP BY DATE(created_at)
           ORDER BY day""",
        (date_from, date_to),
    )
    daily_purchase = query_all(
        """SELECT DATE(purchased_at) AS day, COALESCE(SUM(total_cost),0) AS total
           FROM purchases
           WHERE DATE(purchased_at) BETWEEN %s AND %s
           GROUP BY DATE(purchased_at)
           ORDER BY day""",
        (date_from, date_to),
    )
    ds = {str(r["day"]): float(r["total"] or 0) for r in (daily_sales or [])}
    dp = {str(r["day"]): float(r["total"] or 0) for r in (daily_purchase or [])}

    # build all days in range from -> to (inclusive, safe bound 370 days)
    try:
        d0 = datetime.strptime(date_from, "%Y-%m-%d").date()
        d1 = datetime.strptime(date_to, "%Y-%m-%d").date()
    except Exception:
        d0 = datetime.today().date()
        d1 = d0
    if d1 < d0:
        d0, d1 = d1, d0
    max_days = 370
    cur = d0
    n = 0
    while cur <= d1 and n < max_days:
        k = str(cur)
        s_total = ds.get(k, 0.0)
        p_total = dp.get(k, 0.0)
        ws2.append([k, s_total, p_total, s_total - p_total])
        cur = cur.fromordinal(cur.toordinal() + 1)
        n += 1
    for col in range(1, 5):
        ws2.column_dimensions[get_column_letter(col)].width = 20

    # Sheet 3: Inventory availability
    ws3 = wb.create_sheet("Ketersediaan Stok")
    ws3.append(["ID", "Bahan", "Unit", "Stok", "EOQ", "ROP", "Perlu Pesan Ulang?"])
    for r in inventory_recommendations():
        ws3.append([
            r.get("id"),
            r.get("name"),
            r.get("unit"),
            float(r.get("stock_qty") or 0),
            float(r.get("EOQ") or 0),
            float(r.get("ROP") or 0),
            "YA" if r.get("need_reorder") else "TIDAK",
        ])
    for col in range(1, 8):
        ws3.column_dimensions[get_column_letter(col)].width = 22

    # Sheet 4: Penjualan Detail (menu terjual)
    ws4 = wb.create_sheet("Penjualan Detail")
    ws4.append(["Tanggal", "Kode Pesanan", "Kategori", "Menu", "Qty", "Harga", "Subtotal"])
    for r in (sales_items or []):
        ws4.append([
            r.get("created_at"),
            r.get("order_code"),
            r.get("category_snapshot"),
            r.get("menu_name"),
            int(r.get("qty") or 0),
            float(r.get("unit_price") or 0),
            float(r.get("subtotal") or 0),
        ])
    for col in range(1, 8):
        ws4.column_dimensions[get_column_letter(col)].width = 20

    # Sheet 5: Pemakaian Bahan (stok berkurang karena penjualan)
    ws5 = wb.create_sheet("Pemakaian Bahan")
    ws5.append(["Tanggal", "Kode Pesanan", "Bahan", "Perubahan", "Unit", "Catatan"])
    for r in (ingredient_usage or []):
        ws5.append([
            r.get("created_at"),
            r.get("order_code") or "-",
            r.get("ingredient_name"),
            float(r.get("qty_change") or 0),
            r.get("unit"),
            r.get("note") or "-",
        ])
    for col in range(1, 7):
        ws5.column_dimensions[get_column_letter(col)].width = 20

    # Sheet 6: Pembelian Detail (pengeluaran bahan baku)
    ws6 = wb.create_sheet("Pembelian Detail")
    ws6.append(["Tanggal", "ID Pembelian", "Supplier", "Bahan", "Qty", "Unit", "Harga/Unit", "Total"])
    for r in (purchase_items or []):
        ws6.append([
            r.get("purchased_at"),
            r.get("purchase_code"),
            r.get("supplier_name") or "-",
            r.get("ingredient_name"),
            float(r.get("qty") or 0),
            r.get("unit"),
            float(r.get("unit_cost") or 0),
            float(r.get("total_line") or 0),
        ])
    for col in range(1, 9):
        ws6.column_dimensions[get_column_letter(col)].width = 20

    # stream as file
    bio = BytesIO()
    wb.save(bio)
    bio.seek(0)
    filename = f"laporan_warmindo_{date_from}_sampai_{date_to}.xlsx"
    return send_file(
        bio,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
