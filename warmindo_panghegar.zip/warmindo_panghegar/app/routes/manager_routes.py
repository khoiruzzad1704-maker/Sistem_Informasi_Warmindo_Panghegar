from flask import Blueprint, render_template, jsonify, request, redirect, url_for, session
from app.services.inventory_service import inventory_recommendations
from app.models.purchase_model import list_recent_purchases, create_purchase, add_purchase_item, update_purchase_total, list_recent_purchase_items
from app.models.inventory_model import list_ingredients
from app.services.purchase_service import create_purchase_with_items
from app.db import commit

manager_bp = Blueprint("manager", __name__)


@manager_bp.before_request
def _manager_require_login():
    if not session.get("user"):
        # API requests should get JSON 401, normal requests redirect to login
        if request.path.startswith('/manager') and request.is_json:
            return jsonify({"error": "unauthorized"}), 401
        return redirect(url_for('auth.login_page'))

@manager_bp.get("/inventory")
def inventory_page():
    """Halaman manager: stok & rekomendasi EOQ/ROP."""
    return render_template("manager/inventory.html")

@manager_bp.get("/api/inventory")
def api_inventory():
    """API data stok + EOQ/ROP."""
    return jsonify(inventory_recommendations())


@manager_bp.get("/api/ingredients")
def api_ingredients():
    """API list bahan baku untuk dropdown pembelian."""
    rows = list_ingredients()
    # keep payload slim
    return jsonify([
        {"id": r["id"], "name": r["name"], "unit": r["unit"], "purchase_price": float(r.get("purchase_price") or 0)}
        for r in (rows or [])
    ])


@manager_bp.get("/api/purchase-items")
def api_purchase_items():
    """API rekap pembelian bahan baku (item-level)."""
    return jsonify(list_recent_purchase_items(60))


@manager_bp.post("/api/purchases")
def api_create_purchase():
    """API untuk mencatat pembelian bahan baku dan menambah stok."""
    payload = request.get_json(force=True) or {}
    # normalize payload for service
    supplier = payload.get("supplier_name") or None
    items = payload.get("items") or []
    return jsonify(create_purchase_with_items({"supplier_name": supplier, "items": items}))

@manager_bp.get("/purchases")
def purchases_page():
    """Halaman daftar pembelian bahan baku."""
    purchases = list_recent_purchases()
    return render_template("manager/purchases.html", purchases=purchases)


@manager_bp.post('/purchases/add')
def purchases_add():
    """Tambahkan pembelian bahan baku (minimal single-item form)."""
    # Keep the classic form working, but route it through the same service
    # so stok & inventory_logs also get updated.
    supplier = request.form.get('supplier_name') or None
    ingredient_id = int(request.form.get('ingredient_id', 0) or 0)
    qty = float(request.form.get('qty', 0) or 0)
    unit_cost = float(request.form.get('unit_cost', 0) or 0)

    if ingredient_id and qty > 0:
        create_purchase_with_items({
            "supplier_name": supplier,
            "items": [{"ingredient_id": ingredient_id, "qty": qty, "unit_cost": unit_cost}],
        })
    return redirect(url_for('manager.purchases_page'))
