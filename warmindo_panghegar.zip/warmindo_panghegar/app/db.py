import mysql.connector
from flask import current_app, g

def get_db():
    """Mengembalikan koneksi database yang disimpan di context Flask (`g`)."""
    if "db" not in g:
        cfg = current_app.config
        g.db = mysql.connector.connect(
            host=cfg["DB_HOST"],
            user=cfg["DB_USER"],
            password=cfg["DB_PASS"],
            database=cfg["DB_NAME"],
            autocommit=False,
        )
        # Lightweight migration: ensure `payment_status` column exists in `orders`.
        try:
            cur = g.db.cursor()
            cur.execute("SHOW COLUMNS FROM orders LIKE 'payment_status'")
            found = cur.fetchall()
            if not found:
                cur.execute(
                    "ALTER TABLE orders ADD COLUMN payment_status ENUM('UNPAID','PAID') NOT NULL DEFAULT 'UNPAID'"
                )
                g.db.commit()
            cur.close()
        except Exception:
            # If anything fails here, don't prevent app startup; callers will see DB errors later.
            try:
                cur.close()
            except Exception:
                pass
        
        # Add payment_method column if missing
        try:
            cur = g.db.cursor()
            cur.execute("SHOW COLUMNS FROM orders LIKE 'payment_method'")
            found = cur.fetchall()
            if not found:
                cur.execute(
                    "ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT NULL"
                )
                g.db.commit()
            cur.close()
        except Exception:
            try:
                cur.close()
            except Exception:
                pass
    return g.db

def close_db(e=None):
    """Menutup koneksi database di akhir request."""
    db = g.pop("db", None)
    if db is not None:
        db.close()

def query_all(sql, params=None):
    """Menjalankan SELECT dan mengembalikan list of dict."""
    db = get_db()
    cur = db.cursor(dictionary=True)
    cur.execute(sql, params or ())
    rows = cur.fetchall()
    cur.close()
    return rows

def query_one(sql, params=None):
    """Menjalankan SELECT dan mengembalikan satu baris saja."""
    rows = query_all(sql, params)
    return rows[0] if rows else None

def execute(sql, params=None):
    """Menjalankan INSERT/UPDATE/DELETE dan mengembalikan lastrowid."""
    db = get_db()
    cur = db.cursor()
    cur.execute(sql, params or ())
    last_id = cur.lastrowid
    cur.close()
    return last_id

def commit():
    """Melakukan commit transaksi."""
    get_db().commit()

def rollback():
    """Melakukan rollback transaksi."""
    get_db().rollback()
