from app.db import query_all, query_one, execute

def insert_order(order_code, source, table_id, customer_name, payment_status="UNPAID", payment_method=None):
    """Menyimpan header pesanan baru dan mengembalikan ID-nya."""
    return execute(
        """INSERT INTO orders(order_code, order_source, table_id, customer_name, status, payment_status, payment_method)
            VALUES (%s,%s,%s,%s,'NEW',%s,%s)""",
        (order_code, source, table_id, customer_name, payment_status, payment_method),
    )

def insert_order_item(order_id, menu_id, qty, unit_price, category_snapshot, prep_time_sec_snapshot):
    """Menambahkan satu item ke dalam pesanan."""
    return execute(
        """INSERT INTO order_items(order_id, menu_id, qty, unit_price, category_snapshot, prep_time_sec_snapshot)
            VALUES (%s,%s,%s,%s,%s,%s)""",
        (order_id, menu_id, qty, unit_price, category_snapshot, prep_time_sec_snapshot),
    )

def update_order_total(order_id, total_amount):
    """Mengupdate total nominal pesanan."""
    execute("UPDATE orders SET total_amount=%s WHERE id=%s", (total_amount, order_id))

def get_order_with_items(order_id):
    """Mengambil header pesanan dan seluruh itemnya."""
    order = query_one("SELECT * FROM orders WHERE id=%s", (order_id,))
    items = query_all(
        """SELECT oi.*, m.name
            FROM order_items oi
            JOIN menus m ON m.id = oi.menu_id
            WHERE oi.order_id=%s
            ORDER BY oi.id""",
        (order_id,),
    )
    return order, items

def update_order_status(order_id, status, payment_status=None):
    """Mengubah status pesanan dan/atau status pembayaran."""
    # Update orders table
    if payment_status:
        execute(
            """UPDATE orders
                SET status=%s, payment_status=%s, updated_at=NOW()
                WHERE id=%s""",
            (status, payment_status, order_id),
        )
    else:
        execute(
            """UPDATE orders
                SET status=%s, updated_at=NOW()
                WHERE id=%s""",
            (status, order_id),
        )

    # Keep order_progress in sync so kitchen/runner boards reflect real progress
    try:
        if status == 'IN_PROGRESS':
            # mark all progress rows as IN_PROGRESS and set started_at
            execute(
                """UPDATE order_progress
                    SET status='IN_PROGRESS', started_at=NOW()
                    WHERE order_id=%s""",
                (order_id,),
            )
        elif status == 'READY':
            # mark all progress rows as DONE and set finished_at
            execute(
                """UPDATE order_progress
                    SET status='DONE', finished_at=NOW()
                    WHERE order_id=%s""",
                (order_id,),
            )
        elif status == 'NEW':
            execute(
                """UPDATE order_progress
                    SET status='QUEUED', started_at=NULL, finished_at=NULL
                    WHERE order_id=%s""",
                (order_id,),
            )
    except Exception:
        # don't fail the whole call if progress table update has issues
        pass

    # persist changes immediately
    from app.db import commit
    commit()
    # Recalculate queues so cashier/receipt antrian stay in sync
    try:
        from app.services.queue_service import recalc_food_queue_numbers_today, recalc_drink_queue_numbers_today
        recalc_food_queue_numbers_today()
        recalc_drink_queue_numbers_today()
    except Exception:
        pass

def ensure_progress_row(order_id, category):
    """Memastikan row progress untuk kategori tertentu sudah ada."""
    execute(
        """INSERT IGNORE INTO order_progress(order_id, category, status)
            VALUES (%s,%s,'QUEUED')""",
        (order_id, category),
    )

def board_orders():
    """Mengambil data pesanan yang relevan untuk dashboard staff."""
    return query_all(
        """SELECT
                o.id, o.order_code, o.order_source, o.status,
                o.queue_no_food, o.queue_no_drink,
                o.total_amount, o.created_at,
                dt.table_code,
                dt.table_number
            FROM orders o
            LEFT JOIN dining_tables dt ON dt.id = o.table_id
            WHERE o.status IN ('NEW','IN_PROGRESS','READY')
            ORDER BY o.created_at ASC"""
    )

def queue_now():
    """Mengambil nomor antrian yang sedang diproses saat ini."""
    row = query_one(
        """SELECT
                MAX(queue_no_food) AS food_now,
                MAX(queue_no_drink) AS drink_now
            FROM orders
            WHERE status='IN_PROGRESS'"""
    )
    return row or {"food_now": None, "drink_now": None}
