from app.db import query_all, query_one, execute

def get_active_menus():
    """Mengambil semua menu aktif (untuk website pelanggan)."""
    return query_all(
        """SELECT m.id, m.name, m.price, m.prep_time_sec, c.name AS category
            FROM menus m
            JOIN menu_categories c ON c.id = m.category_id
            WHERE m.is_active = 1
            ORDER BY c.name, m.name"""
    )

def get_all_menus():
    """Mengambil semua menu (aktif & nonaktif) untuk halaman owner."""
    return query_all(
        """SELECT m.id, m.name, m.price, m.prep_time_sec, m.is_active, c.name AS category
            FROM menus m
            JOIN menu_categories c ON c.id = m.category_id
            ORDER BY c.name, m.name"""
    )

def get_menu_by_id(menu_id: int):
    """Mengambil satu menu berdasarkan ID."""
    return query_one(
        """SELECT m.id, m.name, m.price, m.prep_time_sec, c.name AS category
            FROM menus m
            JOIN menu_categories c ON c.id = m.category_id
            WHERE m.id = %s""",
        (menu_id,),
    )

def update_menu_price(menu_id: int, new_price: float):
    """Mengubah harga menu tertentu."""
    execute("UPDATE menus SET price=%s WHERE id=%s", (new_price, menu_id))

def update_menu_active(menu_id: int, is_active: int):
    """Mengatur status aktif/nonaktif menu tertentu."""
    execute("UPDATE menus SET is_active=%s WHERE id=%s", (is_active, menu_id))
