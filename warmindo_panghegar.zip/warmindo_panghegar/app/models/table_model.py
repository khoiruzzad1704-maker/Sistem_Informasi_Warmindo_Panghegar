from app.db import query_one

def get_table_by_code(table_code: str):
    """Mengambil data meja berdasarkan `table_code` dari QR pada meja."""
    if not table_code:
        return None
    return query_one(
        """SELECT id, table_code, table_number
            FROM dining_tables
            WHERE table_code = %s AND is_active = 1""",
        (table_code,),
    )
