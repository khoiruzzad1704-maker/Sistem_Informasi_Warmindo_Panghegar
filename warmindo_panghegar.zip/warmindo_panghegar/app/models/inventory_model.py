from app.db import query_all, query_one, execute

def list_ingredients():
    """Mengambil semua bahan baku aktif."""
    return query_all(
        """SELECT *
            FROM ingredients
            WHERE is_active = 1
            ORDER BY name"""
    )

def get_ingredient(ingredient_id: int):
    """Mengambil satu bahan baku berdasarkan ID."""
    return query_one("SELECT * FROM ingredients WHERE id=%s", (ingredient_id,))

def update_stock(ingredient_id: int, delta: float, ref_type: str, ref_id: int, note: str):
    """Mengubah stok (+/-) dan menulis log ke `inventory_logs`."""
    execute(
        """UPDATE ingredients
            SET stock_qty = stock_qty + %s
            WHERE id=%s""",
        (delta, ingredient_id),
    )
    execute(
        """INSERT INTO inventory_logs(ingredient_id, ref_type, ref_id, qty_change, note)
            VALUES (%s,%s,%s,%s,%s)""",
        (ingredient_id, ref_type, ref_id, delta, note),
    )

def recipe_for_menu(menu_id: int):
    """Mengambil resep bahan untuk satu menu."""
    return query_all(
        """SELECT mi.ingredient_id, mi.qty_needed, i.name, i.unit
            FROM menu_ingredients mi
            JOIN ingredients i ON i.id = mi.ingredient_id
            WHERE mi.menu_id=%s""",
        (menu_id,),
    )
