from datetime import date, timedelta
from app.db import query_all, query_one

def _last_n_days(days: int = 7):
    """List tanggal (YYYY-MM-DD) untuk N hari terakhir termasuk hari ini."""
    n = max(1, int(days or 1))
    today = date.today()
    start = today - timedelta(days=n - 1)
    out = []
    d = start
    while d <= today:
        out.append(d)
        d += timedelta(days=1)
    return out


def sales_summary_days(days: int = 7):
    """Ringkasan penjualan per hari untuk N hari terakhir.

    Catatan: hasil selalu lengkap N hari (hari tanpa data = 0) agar grafik stabil.
    """
    days_list = _last_n_days(days)
    start_day = days_list[0]
    # Statistik 7 hari terakhir untuk dashboard operasional: berdasarkan pesanan yang MASUK.
    # Tidak dibatasi status DELIVERED agar grafik benar-benar merefleksikan pesanan masuk.
    raw = query_all(
        """SELECT DATE(created_at) AS day,
                   SUM(total_amount) AS total_sales,
                   COUNT(*) AS order_count
            FROM orders
            WHERE DATE(created_at) BETWEEN %s AND %s
            GROUP BY DATE(created_at)
            ORDER BY day""",
        (str(start_day), str(days_list[-1])),
    )

    by_day = {str(r["day"]): r for r in (raw or [])}
    filled = []
    for d in days_list:
        k = str(d)
        r = by_day.get(k)
        filled.append({
            "day": k,
            "total_sales": float((r or {}).get("total_sales") or 0),
            "order_count": int((r or {}).get("order_count") or 0),
        })
    return filled

def top_menu_items(limit: int = 5, days: int = 7):
    """Menu terlaris berdasarkan kuantitas (dibatasi N hari terakhir)."""
    days_list = _last_n_days(days)
    start_day = days_list[0]
    return query_all(
        """SELECT m.name, SUM(oi.qty) AS total_qty
            FROM order_items oi
            JOIN orders o ON o.id = oi.order_id
            JOIN menus m ON m.id = oi.menu_id
            WHERE DATE(o.created_at) BETWEEN %s AND %s
            GROUP BY m.id, m.name
            ORDER BY total_qty DESC
            LIMIT %s""",
        (str(start_day), str(days_list[-1]), limit),
    )

def menu_prep_time_stats(limit: int = 7, days: int = 7):
    """Statistik 7 hari terakhir: menu yang dipesan + rata-rata waktu menyiapkan (menit).

    Catatan:
    - Sistem menyimpan waktu proses per-order per-kategori (MAKANAN/MINUMAN) di tabel order_progress.
    - Untuk mendapatkan estimasi per-menu, durasi kategori pada order tersebut diasumsikan berlaku
      untuk item-item dalam kategori yang sama, lalu dihitung rata-rata tertimbang berdasarkan qty.
    """
    days_list = _last_n_days(days)
    start_day = days_list[0]
    rows = query_all(
        """SELECT
                m.name,
                SUM(oi.qty) AS total_qty,
                (SUM(TIMESTAMPDIFF(SECOND, op.started_at, op.finished_at) * oi.qty) / NULLIF(SUM(oi.qty),0)) AS avg_sec
            FROM order_items oi
            JOIN orders o ON o.id = oi.order_id
            JOIN menus m ON m.id = oi.menu_id
            JOIN order_progress op
              ON op.order_id = o.id
             AND op.category = oi.category_snapshot
            WHERE op.started_at IS NOT NULL AND op.finished_at IS NOT NULL
              AND DATE(op.finished_at) BETWEEN %s AND %s
            GROUP BY m.id, m.name
            ORDER BY total_qty DESC
            LIMIT %s""",
        (str(start_day), str(days_list[-1]), limit),
    )
    out = []
    for r in (rows or []):
        avg_min = (float(r.get("avg_sec") or 0) / 60.0)
        out.append({
            "name": r.get("name"),
            "total_qty": int(r.get("total_qty") or 0),
            "avg_min": round(avg_min, 1),
        })
    return out

def avg_prep_times(days: int = 7):
    """Rata-rata waktu proses makanan dan minuman (menit) untuk N hari terakhir."""
    days_list = _last_n_days(days)
    start_day = days_list[0]
    row = query_one(
        """SELECT
                AVG(IF(category='MAKANAN', TIMESTAMPDIFF(SECOND, started_at, finished_at), NULL)) AS food_sec,
                AVG(IF(category='MINUMAN', TIMESTAMPDIFF(SECOND, started_at, finished_at), NULL)) AS drink_sec
            FROM order_progress
            WHERE started_at IS NOT NULL AND finished_at IS NOT NULL
              AND DATE(finished_at) BETWEEN %s AND %s""",
        (str(start_day), str(days_list[-1])),
    )
    food = (row["food_sec"] or 0) / 60.0
    drink = (row["drink_sec"] or 0) / 60.0
    return {"food_min": round(food, 1), "drink_min": round(drink, 1)}

def dashboard_stats():
    """Menggabungkan beberapa statistik untuk dashboard staff."""
    # Last 7 days stats based on real order & kitchen processing data
    sales = sales_summary_days(7)
    top = top_menu_items(5, 7)
    menu_prep = menu_prep_time_stats(7, 7)
    prep = avg_prep_times(7)
    return {
        "sales": {
            "labels": [str(r["day"]) for r in sales],
            "values": [float(r["total_sales"] or 0) for r in sales],
            "orders": [int(r["order_count"] or 0) for r in sales],
        },
        "topMenus": {
            "labels": [r["name"] for r in top],
            "values": [int(r["total_qty"] or 0) for r in top],
        },
        "menuPrep": {
            "labels": [r["name"] for r in menu_prep],
            "values": [float(r["avg_min"] or 0) for r in menu_prep],
            "qty": [int(r["total_qty"] or 0) for r in menu_prep],
        },
        "prep": prep,
    }

def profit_summary(date_from: str, date_to: str):
    """Menghitung laba = total penjualan - total pembelian pada rentang tanggal."""
    s = query_one(
        """SELECT COALESCE(SUM(total_amount),0) AS total_sales
            FROM orders
            WHERE status='DELIVERED'
              AND DATE(created_at) BETWEEN %s AND %s""",
        (date_from, date_to),
    )["total_sales"]
    p = query_one(
        """SELECT COALESCE(SUM(total_cost),0) AS total_purchase
            FROM purchases
            WHERE DATE(purchased_at) BETWEEN %s AND %s""",
        (date_from, date_to),
    )["total_purchase"]
    return {
        "total_sales": float(s),
        "total_purchase": float(p),
        "profit": float(s) - float(p),
    }
