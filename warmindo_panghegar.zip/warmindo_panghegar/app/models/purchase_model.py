from app.db import execute, query_all, query_one

def create_purchase(purchase_code: str, supplier_name: str | None):
    """Membuat header pembelian baru dan mengembalikan ID-nya."""
    return execute(
        """INSERT INTO purchases(purchase_code, supplier_name)
            VALUES (%s,%s)""",
        (purchase_code, supplier_name),
    )

def add_purchase_item(purchase_id: int, ingredient_id: int, qty: float, unit_cost: float):
    """Menambahkan item pembelian ke tabel `purchase_items`."""
    return execute(
        """INSERT INTO purchase_items(purchase_id, ingredient_id, qty, unit_cost)
            VALUES (%s,%s,%s,%s)""",
        (purchase_id, ingredient_id, qty, unit_cost),
    )

def update_purchase_total(purchase_id: int):
    """Menghitung total biaya pembelian dan menyimpannya ke header."""
    row = query_one(
        """SELECT SUM(qty * unit_cost) AS total
            FROM purchase_items
            WHERE purchase_id=%s""",
        (purchase_id,),
    )
    total = row["total"] or 0
    execute("UPDATE purchases SET total_cost=%s WHERE id=%s", (total, purchase_id))

def list_recent_purchases(limit: int = 20):
    """Mengambil daftar pembelian terakhir untuk halaman manager."""
    return query_all(
        """SELECT p.*, SUM(pi.qty * pi.unit_cost) AS total_cost
            FROM purchases p
            LEFT JOIN purchase_items pi ON pi.purchase_id = p.id
            GROUP BY p.id
            ORDER BY p.purchased_at DESC
            LIMIT %s""",
        (limit,),
    )


def list_recent_purchase_items(limit: int = 50):
    """Rekap item pembelian terbaru (join purchases + ingredients).

    Output fields (untuk UI):
    - purchase_id
    - purchase_code
    - purchased_at
    - ingredient_name
    - unit_cost
    - qty
    - total_price
    """
    return query_all(
        """SELECT
              p.id AS purchase_id,
              p.purchase_code,
              p.purchased_at,
              i.name AS ingredient_name,
              pi.unit_cost,
              pi.qty,
              (pi.qty * pi.unit_cost) AS total_price
            FROM purchase_items pi
            JOIN purchases p ON p.id = pi.purchase_id
            JOIN ingredients i ON i.id = pi.ingredient_id
            ORDER BY p.purchased_at DESC, pi.id DESC
            LIMIT %s""",
        (limit,),
    )
