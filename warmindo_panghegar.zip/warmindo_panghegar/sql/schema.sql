CREATE DATABASE IF NOT EXISTS warmindo_panghegar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE warmindo_panghegar;


-- ROLES
CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL
);

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role_id INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- DINING TABLES
CREATE TABLE IF NOT EXISTS dining_tables (
  id INT AUTO_INCREMENT PRIMARY KEY,
  table_code VARCHAR(20) UNIQUE NOT NULL,
  table_number INT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
);

-- MENU CATEGORIES
CREATE TABLE IF NOT EXISTS menu_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL
);

-- MENUS
CREATE TABLE IF NOT EXISTS menus (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category_id INT NOT NULL,
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  prep_time_sec INT NOT NULL DEFAULT 300,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (category_id) REFERENCES menu_categories(id)
);

-- INGREDIENTS
CREATE TABLE IF NOT EXISTS ingredients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) UNIQUE NOT NULL,
  unit VARCHAR(20) NOT NULL,
  stock_qty DECIMAL(12,2) NOT NULL DEFAULT 0,
  safety_stock DECIMAL(12,2) NOT NULL DEFAULT 0,
  lead_time_days INT NOT NULL DEFAULT 1,
  daily_demand_avg DECIMAL(12,2) NOT NULL DEFAULT 0,
  ordering_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
  holding_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
  purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS menu_ingredients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  menu_id INT NOT NULL,
  ingredient_id INT NOT NULL,
  qty_needed DECIMAL(12,2) NOT NULL,
  UNIQUE(menu_id, ingredient_id),
  FOREIGN KEY (menu_id) REFERENCES menus(id),
  FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

CREATE TABLE IF NOT EXISTS inventory_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ingredient_id INT NOT NULL,
  ref_type ENUM('SALE','PURCHASE','ADJUST') NOT NULL,
  ref_id INT NULL,
  qty_change DECIMAL(12,2) NOT NULL,
  note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

-- ORDERS
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(30) UNIQUE NOT NULL,
  order_source ENUM('QR','CASHIER') NOT NULL,
  table_id INT NULL,
  customer_name VARCHAR(120) NULL,
  status ENUM('NEW','IN_PROGRESS','READY','DELIVERED','CANCELLED') NOT NULL DEFAULT 'NEW',
  payment_status ENUM('UNPAID','PAID') NOT NULL DEFAULT 'UNPAID',
  queue_no_food INT NULL,
  queue_no_drink INT NULL,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  FOREIGN KEY (table_id) REFERENCES dining_tables(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menu_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
  category_snapshot ENUM('MAKANAN','MINUMAN') NOT NULL,
  prep_time_sec_snapshot INT NOT NULL DEFAULT 300,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (menu_id) REFERENCES menus(id)
);

CREATE TABLE IF NOT EXISTS order_progress (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  category ENUM('MAKANAN','MINUMAN') NOT NULL,
  status ENUM('QUEUED','IN_PROGRESS','DONE') NOT NULL DEFAULT 'QUEUED',
  started_at DATETIME NULL,
  finished_at DATETIME NULL,
  UNIQUE(order_id, category),
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- PURCHASES
CREATE TABLE IF NOT EXISTS purchases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_code VARCHAR(30) UNIQUE NOT NULL,
  supplier_name VARCHAR(120) NULL,
  purchased_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_cost DECIMAL(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS purchase_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_id INT NOT NULL,
  ingredient_id INT NOT NULL,
  qty DECIMAL(12,2) NOT NULL,
  unit_cost DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (purchase_id) REFERENCES purchases(id),
  FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

-- Roles
INSERT INTO roles(name) VALUES ('OWNER'),('MANAGER'),('EMPLOYEE'),('CASHIER') ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Meja untuk QR
INSERT INTO dining_tables(table_code, table_number, is_active) VALUES
('T1', 1, 1),
('T2', 2, 1),
('T3', 3, 1),
('T4', 4, 1),
('T5', 5, 1),
('T6', 6, 1),
('T7', 7, 1),
('T8', 8, 1),
('T9', 9, 1),
('T10', 10, 1);

-- Kategori menu
INSERT INTO menu_categories(id, name) VALUES (1,'MAKANAN'),(2,'MINUMAN') ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Menu makanan & minuman
INSERT INTO menus(id, name, category_id, price, prep_time_sec, is_active) VALUES
(1, 'Burjo', 1, 7000, 420, 1),
(2, 'Buryam', 1, 10000, 420, 1),
(3, 'Ketoprak+Tekur', 1, 15000, 420, 1),
(4, 'Ayam Gerek', 1, 15000, 720, 1),
(5, 'Ayam Penyet', 1, 17000, 720, 1),
(6, 'Nila Penyet', 1, 17000, 420, 1),
(7, 'Tahu/Tempe', 1, 3000, 300, 1),
(8, 'Rempelo Ati Penyet', 1, 13000, 420, 1),
(9, 'Nasgor', 1, 13000, 480, 1),
(10, 'Magelangan', 1, 13000, 480, 1),
(11, 'Mie Goreng Special', 1, 13000, 480, 1),
(12, 'Mie Rebus Spesial', 1, 13000, 480, 1),
(13, 'Mie Dok Dok', 1, 13000, 480, 1),
(14, 'Nasi Ikan', 1, 13000, 720, 1),
(15, 'Nasi Ayam', 1, 12000, 720, 1),
(16, 'Nasi Orak Arik', 1, 9000, 420, 1),
(17, 'Nasi Sayur', 1, 7000, 420, 1),
(18, 'Nasi Telur Balado', 1, 10000, 420, 1),
(19, 'Nasi Telur Dadar', 1, 9000, 420, 1),
(20, 'Nasi Telur Asin', 1, 11000, 420, 1),
(21, 'Nasi Putih', 1, 3000, 420, 1),
(22, 'Nasi rendangSapi', 1, 17000, 420, 1),
(23, 'Nasi Rendang Ayam', 1, 13000, 720, 1),
(24, 'Nasi Ayam Opor', 1, 13000, 720, 1),
(25, 'Nasi Lele Balado', 1, 13000, 720, 1),
(26, 'Nasi Tongkol', 1, 15000, 720, 1),
(27, 'Gorengan', 1, 1000, 300, 1),
(28, 'Es Oyen', 2, 12000, 120, 1),
(29, 'Es Buah', 2, 12000, 120, 1),
(30, 'Sogem', 2, 15000, 180, 1),
(31, 'Susu Milo', 2, 10000, 240, 1),
(32, 'Joshua (Extra Jos + Susu Putih)', 2, 10000, 180, 1),
(33, 'Es Sus (Sirup + Prambos)', 2, 10000, 120, 1),
(34, 'Dancow', 2, 10000, 180, 1),
(35, 'Soft Drink', 2, 6000, 120, 1),
(36, 'air Mineral', 2, 5000, 60, 1),
(37, 'Lemon Tea', 2, 5000, 180, 1),
(38, 'Tek Ttarik', 2, 10000, 180, 1),
(39, 'Chocolatos (coklat/matcha)', 2, 10000, 240, 1),
(40, 'Good dayBeng Beng', 2, 10000, 240, 1),
(41, 'Milo', 2, 6000, 240, 1),
(42, 'enegen', 2, 6000, 180, 1),
(43, 'Susu Putih', 2, 10000, 180, 1),
(44, 'Susu Coklat', 2, 10000, 180, 1),
(45, 'STMJ', 2, 10000, 240, 1),
(46, 'Adem Sari', 2, 5000, 180, 1),
(47, 'Es Sirup Prambos', 2, 5000, 120, 1),
(48, 'Extra Jos', 2, 4000, 180, 1),
(49, 'Kukubima', 2, 4000, 180, 1),
(50, 'Nescafe', 2, 6000, 180, 1),
(51, 'Kopma', 2, 5000, 180, 1),
(52, 'Jerman', 2, 4000, 180, 1),
(53, 'eman', 2, 4000, 180, 1),
(54, 'Air Es', 2, 2000, 60, 1),
(55, 'Es Batu', 2, 2000, 60, 1) ON DUPLICATE KEY UPDATE name=VALUES(name), price=VALUES(price), prep_time_sec=VALUES(prep_time_sec), is_active=VALUES(is_active);

-- Bahan baku dengan parameter EOQ/ROP
INSERT INTO ingredients(id, name, unit, stock_qty, safety_stock, lead_time_days, daily_demand_avg, ordering_cost, holding_cost, purchase_price, is_active) VALUES
(1, 'Beras', 'kg', 25, 5, 2, 3.5, 45000, 2500, 12000, 1),
(2, 'Telur', 'butir', 200, 40, 2, 60, 20000, 500, 2000, 1),
(3, 'Daging Ayam', 'kg', 15, 4, 2, 3, 50000, 3000, 38000, 1),
(4, 'Daging Sapi Rendang', 'kg', 10, 3, 3, 2, 60000, 4000, 85000, 1),
(5, 'Ikan Nila', 'kg', 8, 2, 2, 1.5, 50000, 3000, 35000, 1),
(6, 'Ikan Tongkol', 'kg', 8, 2, 2, 1.5, 50000, 3000, 30000, 1),
(7, 'Ikan Lele', 'kg', 8, 2, 2, 1.5, 45000, 2500, 28000, 1),
(8, 'Mie Instan', 'pak', 120, 30, 3, 40, 15000, 400, 3500, 1),
(9, 'Sayur Campur', 'kg', 12, 3, 2, 2.5, 25000, 1500, 12000, 1),
(10, 'Minyak Goreng', 'liter', 25, 5, 3, 3.5, 40000, 2500, 18000, 1),
(11, 'Bumbu Instan', 'pak', 150, 30, 4, 45, 20000, 600, 2500, 1),
(12, 'Gula Pasir', 'kg', 20, 4, 3, 3, 30000, 1500, 14000, 1),
(13, 'Teh', 'pak', 80, 20, 3, 20, 15000, 400, 5000, 1),
(14, 'Kopi Bubuk', 'pak', 60, 15, 3, 15, 15000, 400, 7000, 1),
(15, 'Susu Bubuk', 'pak', 60, 15, 3, 15, 18000, 500, 9000, 1),
(16, 'Susu Kental Manis', 'kaleng', 40, 10, 3, 12, 20000, 600, 8000, 1),
(17, 'Sirup', 'botol', 30, 6, 3, 8, 25000, 800, 12000, 1),
(18, 'Bubuk Minuman Sachet', 'sachet', 200, 40, 4, 60, 15000, 400, 2000, 1),
(19, 'Es Batu', 'kg', 30, 5, 1, 6, 10000, 300, 2000, 1) ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Resep sederhana per menu
INSERT INTO menu_ingredients(menu_id, ingredient_id, qty_needed) VALUES
(1, 1, 0.17),
(1, 11, 1.00),
(2, 1, 0.15),
(2, 11, 1.00),
(3, 1, 0.15),
(3, 11, 1.00),
(4, 3, 0.18),
(5, 3, 0.18),
(6, 1, 0.15),
(6, 11, 1.00),
(7, 10, 0.02),
(8, 1, 0.15),
(8, 11, 1.00),
(9, 8, 1.00),
(9, 11, 1.00),
(10, 8, 1.00),
(10, 11, 1.00),
(11, 8, 1.00),
(11, 11, 1.00),
(12, 8, 1.00),
(12, 11, 1.00),
(13, 8, 1.00),
(13, 11, 1.00),
(14, 1, 0.17),
(14, 11, 1.00),
(14, 6, 0.20),
(15, 1, 0.17),
(15, 11, 1.00),
(15, 3, 0.18),
(16, 1, 0.17),
(16, 11, 1.00),
(17, 1, 0.17),
(17, 11, 1.00),
(18, 1, 0.17),
(18, 11, 1.00),
(18, 2, 1.00),
(19, 1, 0.17),
(19, 11, 1.00),
(19, 2, 1.00),
(20, 1, 0.17),
(20, 11, 1.00),
(20, 2, 1.00),
(21, 1, 0.17),
(21, 11, 1.00),
(22, 1, 0.17),
(22, 11, 1.00),
(23, 1, 0.17),
(23, 11, 1.00),
(23, 3, 0.18),
(23, 4, 0.18),
(24, 1, 0.17),
(24, 11, 1.00),
(24, 3, 0.18),
(25, 1, 0.17),
(25, 11, 1.00),
(25, 7, 0.20),
(26, 1, 0.17),
(26, 11, 1.00),
(26, 6, 0.20),
(27, 10, 0.02),
(28, 19, 0.20),
(28, 17, 0.05),
(29, 19, 0.20),
(29, 17, 0.05),
(30, 12, 0.01),
(30, 19, 0.10),
(31, 15, 1.00),
(31, 16, 0.50),
(32, 15, 1.00),
(32, 16, 0.50),
(32, 18, 1.00),
(32, 19, 0.10),
(32, 12, 0.01),
(33, 19, 0.20),
(33, 17, 0.05),
(33, 17, 0.05),
(33, 19, 0.15),
(34, 15, 1.00),
(34, 16, 0.50),
(35, 12, 0.01),
(35, 19, 0.10),
(36, 19, 0.10),
(36, 12, 0.01),
(37, 12, 0.01),
(37, 19, 0.10),
(38, 12, 0.01),
(38, 19, 0.10),
(39, 18, 1.00),
(39, 19, 0.10),
(39, 12, 0.01),
(40, 18, 1.00),
(40, 19, 0.10),
(40, 12, 0.01),
(41, 15, 1.00),
(41, 16, 0.50),
(42, 18, 1.00),
(42, 19, 0.10),
(42, 12, 0.01),
(43, 15, 1.00),
(43, 16, 0.50),
(44, 15, 1.00),
(44, 16, 0.50),
(45, 15, 1.00),
(45, 16, 0.50),
(46, 18, 1.00),
(46, 19, 0.10),
(46, 12, 0.01),
(47, 19, 0.20),
(47, 17, 0.05),
(47, 17, 0.05),
(47, 19, 0.15),
(48, 18, 1.00),
(48, 19, 0.10),
(48, 12, 0.01),
(49, 18, 1.00),
(49, 19, 0.10),
(49, 12, 0.01),
(50, 14, 1.00),
(50, 12, 0.02),
(51, 14, 1.00),
(51, 12, 0.02),
(52, 18, 1.00),
(52, 19, 0.10),
(52, 12, 0.01),
(53, 18, 1.00),
(53, 19, 0.10),
(53, 12, 0.01),
(54, 19, 0.10),
(54, 12, 0.01),
(55, 19, 0.20),
(55, 17, 0.05);