from app import create_app

# Membuat instance aplikasi Flask
app = create_app()

if __name__ == "__main__":
    # Jalankan aplikasi dalam mode debug untuk pengembangan
    app.run(debug=True)
