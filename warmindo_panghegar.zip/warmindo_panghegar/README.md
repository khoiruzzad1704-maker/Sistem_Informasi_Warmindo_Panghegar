# Sistem Informasi Warmindo Panghegar

Backend: Flask + MySQL  
Frontend: HTML + CSS + JavaScript (tanpa framework)

## Langkah Instalasi Singkat

1. Nyalakan Apache & MySQL di XAMPP.
2. Buat database `warmindo_panghegar`.
3. Import `sql/schema.sql` ke MySQL (via phpMyAdmin / CLI).
4. Install package Python:

   ```bash
   pip install -r requirements.txt
   ```

5. Jalankan server:

   ```bash
   python run.py
   ```

6. Akses:
   - Pelanggan: `http://127.0.0.1:5000/`
   - Staff kitchen: `http://127.0.0.1:5000/staff/kitchen`
   - Staff runner: `http://127.0.0.1:5000/staff/runner`
   - Manager inventory: `http://127.0.0.1:5000/manager/inventory`
   - Owner menu: `http://127.0.0.1:5000/owner/menu`
   - Owner laporan: `http://127.0.0.1:5000/owner/finance`
